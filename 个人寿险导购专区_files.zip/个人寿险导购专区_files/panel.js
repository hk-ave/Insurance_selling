var ebt = ebt||{};
(function() {

    //获取运行设备的视口高度和宽度
    this.win={
        //iframe在隐藏的情况下获取的值为0
        width :function(){
            var res=$(window).width();
            return res;
        }(),
        height :function(){
            var res=$(window).height();
            return res;
        }()
    };

    this.isObject=function(o){
        return typeof o == "object";
    };

    this.isFunction=function(o){
        return typeof o == "function";
    };

    this.isBoolean=function(o){
        return typeof o == "boolean";
    };

    var exports={},

        that=ebt,

        _idPrefix="cpic-panel-",//自定义id前缀

        _id=0;

    /**
     * 组件主函数
     * @param param 组件调用时初始化参数集合
     */
    function panel(param)
    {
        //定义组件创建以及事件处理主体对象
        /**
         * 打开时追加的className
         */
        this.openClass="one_panel_open";
        /**
         * 遮罩层的className
         */
        this.maskClass="one_panel_mask";
        /**
         * 遮罩层的className
         */
        this.maskClassOpen="one_panel_mask_open";
        /**
         * 显示className
         */
        this.blockClass="one_panel_block";
        /**
         * left className
         */
        this.leftClass="one_panel_left";
        /**
         * right className
         */
        this.rightClass="one_panel_right";
        /**
         * content className
         */
        this.panelContentClass="one_panel_content";

        /**
         * 默认参数
         */
        this.options={
            id : "",
            content:"",//内容
            type:"dataList",//类型 目前可选dataList
            dataList:[],
            lockScroll:false,//是否锁定滚动条
            header_backT:true,//是否控制头部返回按钮
            ready:function(){},
            before:function(){},//显示和隐藏之前回调函数,return false可阻止当前操作
            change:function(){},//显示和隐藏之后回调函数
            selectData:function(){}//选择数据之后回调函数
        };

        /**
         * 储存初始化参数
         */
        this.param=param;

        /**
         * 缓存组件对象
         */
        this.panels=null;

        /**
         * 遮罩层组件缓存对象
         */
        this.mask=null;

        /**
         * 回调函数集合
         */
        this.callBacks={};

        /**
         * 组件结构模板
         */
        this._template='<div class="one_panel one_panel_animate">'
        +'<div class="one_panel_content"></div>'
        +'</div>';

        /**
         * 组件遮罩层结构模板
         */
        this._maskTemplate='<div class="one_panel_mask"></div>';

        this.init();
    }

    panel.prototype={
        lockHeaderBackT:function(){
            if($(".header_backT").size()>0&&this.options.header_backT){
                this.header_backT_old=$(".header_backT")[0].onclick;

                this.backFun=function(){

                    this.close();

                }.bind(this);

                $(".header_backT").bind(that.e.tap,this.backFun);

                $(".header_backT")[0].onclick=function(e){

                    e.preventDefault();
                    e.stopPropagation();
                };
            }
        },
        unLockHeaderBackT:function(){
            if (this.header_backT_old) {

                $(".header_backT").unbind(that.e.tap,this.backFun);

                setTimeout(function(){
                    $(".header_backT")[0].onclick = this.header_backT_old;
                },500);
            }
        },
        setDataList:function(data){
            //this.panels
            var html=[],attrs=[];
            data.forEach(function(d){
                attrs=[];
                for(var t in d){
                    attrs.push("data-"+t+"=\""+d[t]+"\"");
                }
                html.push("<li "+attrs.join(" ")+">"+d.t+"</li>");
                if(d.def===true){
                    html.push(html.pop().replace("<li","<li class='active'"));
                }
            });
            this.panels.children("."+this.panelContentClass).html("<ul class='dataList'>"+html.join("")+"</ul>")
        },
        /**
         * 执行回调函数
         * @param name 回调函数名称
         * @param context 执行回调函数的上下文(即改变执行函数中this指针)
         * @param params 执行回调函数时传入的参数集合(数组)
         * @returns 回调函数返回的结果
         */
        runCallBack:function(name,context,params,isCall){
            var result;
            if (that.isFunction(this.callBacks[name])) {
                if(context){
                    if(isCall){
                        result=this.callBacks[name].call(context,params);
                    }else{
                        result=this.callBacks[name].apply(context,params);
                    }
                }else{
                    result=this.callBacks[name](params);
                }
            }
            return result;
        },

        /**
         * 绑定回调函数
         * @param name 回调函数名称
         * @param fn 回调函数
         */
        bindCallBack:function(name,fn){

            //删除原回调函数
            delete this.callBacks[name];

            //如果fn参数类型为function则绑定
            if(that.isFunction(fn)){
                this.callBacks[name]=fn;
            }
        },

        /**
         * 绑定遮罩层点击事件
         */
        bindCloseEvent:function() {
            if(this.mask){
                var _me=this;
                this.mask.off().on(that.e.tap,function(){
                    _me.close(this);
                });
            }
        },
        /**
         * 初始化回调函数
         */
        initCallBack:function(){

            //绑定组件初始化完成回调函数
            this.bindCallBack("ready",this.options.ready);

            //改变状态之前回调事件绑定
            this.bindCallBack("before",this.options.before);

            //绑定改变状态时回调函数
            this.bindCallBack("change",this.options.change);

            //绑定改变状态时回调函数
            this.bindCallBack("selectData",this.options.selectData);
        },
        /**
         * 初始化组件函数
         */
        init:function() {
            //object作为单个对象处理
            var _me=this;
            if(that.isObject(this.param)){
                //使用传入的参数覆盖默认参数
                $.extend(this.options, this.param);

                //如果未传入id,使用自定义规则生成的ID
                if (!this.options.id) {
                    this.options.id = _idPrefix + (++_id);
                }

                //查找组件
                this.panels = $("#"+this.options.id);

                //如果未存在指定id的组件,则创建
                if(this.panels.size()<1)
                {
                    //把模板变为Zepto DOM对象
                    this.panels=$(this._template);

                    this.panels.children("."+this.panelContentClass).append(this.options.content);

                    //设置ID
                    this.panels.attr("id", this.options.id);

                    if(this.options.type=="dataList"){

                        this.setDataList(this.options.dataList);
                        this.panels[0].addEventListener("touchmove",function(e){
                            e.preventDefault();
                            e.stopPropagation();
                        },false);

                        this.panels.on(that.e.tap,"li",function(e){
                            $(this).addClass("active").siblings().removeClass("active");
                            _me.close();
                            _me.runCallBack("selectData",this,_me.options.dataList[$(this).index()],true);
                            e.preventDefault();
                            e.stopPropagation();
                        });
                    }

                    //把html追加到指定容器中
                    $("body").append(this.panels);
                }

                if(!this.mask){
                    this.mask=$(this._maskTemplate);

                    this.mask[0].addEventListener("touchmove",function(e){
                        e.preventDefault();
                        e.stopPropagation();
                    },false);

                    //把html追加到指定容器中
                    this.panels.before(this.mask);
                }
            }

            //初始化回调函数
            this.initCallBack();

            //绑定事件处理
            this.bindCloseEvent();

            //执行组件初始化完成回调函数
            this.runCallBack("ready",this.options.ready);
        },
        /**
         * 改变状态之前回调函数
         * @param fn 组件改变状态之前回调函数
         */
        before:function(fn){
            this.bindCallBack("before",fn);
            return this;
        },
        /**
         * 改变为on状态时回调函数
         * @param fn 回调函数
         */
        change:function(fn){
            this.bindCallBack("change",fn);
            return this;
        },
        selectData:function(fn){
            this.bindCallBack("selectData",fn);
            return this;
        },
        /**
         * 打开panel
         */
        open:function(position){

            //默认从左边打开
            position=position||"right";

            var _me=this,
                hheight=0,
                scrollTop=$(window).scrollTop();

            if($(".headerT").size()>0){
                hheight=$(".headerT").height();
            }

            hheight-=(scrollTop>hheight?hheight:scrollTop);

            this.lockHeaderBackT();

            if(this.options.lockScroll){
                that.lockBodyScroll();
            }

            //先调用before回调函数
            var result=_me.runCallBack("before",this,["open",position]);

            //如果事件处理回调函数返回的值为false时阻止本次操作
            if(!that.isBoolean(result)||result){

                var _$this=this.panels;

                //移除left和right样式
                _$this.removeClass(_me.leftClass+" "+_me.rightClass)
                    //设置当前左或右
                    .addClass(position=="left"?_me.leftClass:_me.rightClass);

                //设置panel高度和计算内容距离顶部的值(取滚动条位置)

                _$this.height(that.win.height-hheight)
                    .addClass(_me.blockClass)
                    .css("margin-top",hheight)
                    .children("."+_me.panelContentClass);

                //如果立即追加class动画效果无效
                setTimeout(function(){
                    _$this.addClass(_me.openClass);
                },10);

                //调用change回调函数
                _me.runCallBack("change",this,["open",position]);
            }

            //显示遮罩层
            this.mask.css("margin-top",hheight)
                .addClass(_me.blockClass);

            setTimeout(function(){
                _me.mask.addClass(_me.maskClassOpen);
            },10);
        },
        /**
         * 关闭panel
         */
        close:function(){

            this.unLockHeaderBackT();

            if(this.options.lockScroll){
                that.unLockBodyScroll();
            }

            var _me=this;

            function closePanel(callC,mask,params)
            {
                //获取当前位置
                position=callC.hasClass(_me.leftClass)?"left":"right";
                params.push(position);

                //先调用before回调函数
                var result=_me.runCallBack("before",callC[0],params);

                if(!that.isBoolean(result)||result){

                    //处理动画完成事件
                    function handler(){
                        //隐藏panel
                        $(this).removeClass(_me.blockClass);

                        //移除事件监听
                        // Chrome, Safari, Opera
                        this.removeEventListener("webkitTransitionEnd",arguments.callee, false);
                        // 标准语法
                        this.removeEventListener("transitionend",arguments.callee, false);
                    }//处理动画完成事件
                    function handler2(){
                        //隐藏panel
                        $(this).removeClass(_me.blockClass);

                        //移除事件监听
                        // Chrome, Safari, Opera
                        this.removeEventListener("webkitTransitionEnd",arguments.callee, false);
                        // 标准语法
                        this.removeEventListener("transitionend",arguments.callee, false);
                    }

                    // Chrome, Safari, Opera
                    callC[0].addEventListener("webkitTransitionEnd",handler, false);
                    // 标准语法
                    callC[0].addEventListener("transitionend",handler, false);

                    //关闭panel
                    callC.removeClass(_me.openClass);


                    // Chrome, Safari, Opera
                    mask[0].addEventListener("webkitTransitionEnd",handler2, false);
                    // 标准语法
                    mask[0].addEventListener("transitionend",handler2, false);

                    //移除遮罩层
                    mask.removeClass(_me.maskClassOpen);
                    //调用change回调函数
                    _me.runCallBack("change",callC[0],params);
                }
            }
            closePanel(this.panels,this.mask,["close"]);
        }
    };

    this.panel = panel;
}).call(ebt);