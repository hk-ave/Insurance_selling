$(function(){
    var gchannel = ebt.gchannel();
    var openid = ebt.getQueryString("openid")||"";

    function init(){
        ebt.addHeaderHtml();
        jinpai();
        setData();
        setFunClick();//添加事件
        initVali();//验证
        ebt.pageShare(gchannel,openid,"");//分享
        setOM();//部署
    }
  /*  window.onorientationchange = function(){
        function orientationChange() {
            if(window.orientation == 0){//竖屏
                $(".top_one").removeClass("top_lalal");
            }
            if(window.orientation !== 0){//横屏
                $(".top_one").addClass("top_lalal");
            }
        };
    };*/
    function setData(){
        var data = ebt.getSessionStorage("data_llifeinsure",true)||"";
        if(data=="") return;
        $("#city").val(data.cityVal).attr("data-val",data.cityDataVal);
        $("#sex").val(data.sexVal).attr("data-val",data.sexDataVal);
    }
    function submitto(e) {
        $(".form-error").remove();
        if (!ebt.valiformdata.check(null,function(message, id){
                ebt.valiDataCallBack(message, id,"1");
            })) {
            event.stopPropagation()
            return;
        }

        var $city = $("#city"),$sex = $("#sex");
        var cityData = $.parseJSON($city.attr("data-val"));
        ebt.action.E1096({
            request: {
                provinceCode: cityData.province.id,//省
                cityCode: cityData.city.id,//市
                districtCode:'',//区/县
                gender:$sex.attr("data-val")//性别
            },
            callback: function (response, status) {
                if (response.errorCode != ebt.errorCode.A0000000) {
                    ebt.showMessage({message: response.errorMsg || "请求服务器异常！"});
                    return;
                }
                if (response.responseBody.resultCode != "1") {
                    ebt.showMessage({message: response.responseBody.resultMsg || "查询失败！"});
                    return;
                }
                if (response.responseBody.bizInfoResultVo.bizInfoVos == ''|| response.responseBody.bizInfoResultVo.bizInfoVos == undefined) {
                    ebt.showMessage({message: "我们正在为您评选金牌顾问，敬请期待，也可以在保险产品中留下您的信息，我们会安排顾问直接与您联系"});
                    return;
                }
                console.log(response);
                var data = {};
                data.data = response.responseBody;
                data.cityDataVal = $city.attr("data-val");
                data.cityVal = $city.val();
                data.sexVal = $sex.val();
                data.sexDataVal = $sex.attr("data-val");
                ebt.setSessionStorage("data_llifeinsure",data,true);
                window.location.href = "personellist.html"+(openid==""?"":"?openid="+openid);
            }
        });
        event.stopPropagation();
    }
    function jinpai(){
        /*$(document).on('touchstart',function(e){*/
        if(gchannel == "W"){
            $('.fl-show').show();
        }
            $(window).on('scroll',function(){
               if($(window).scrollTop()>=$("header").height()){
                    $(".top_one").addClass('top-123');
                   $("#top-123").css("height",$(".top_one").height()+'px')
               }else{
                   $(".top_one").removeClass('top-123');
                   $("#top-123").css("height","0");
               }
            })
        /*})*/
        $("#anxingbao").on("tap",function(){
            window.location.href = "../anxingbao/index.html"+(openid==""?"":"?openid="+openid);
        })
        $("#huayangnian").on("tap",function(){
            window.location.href = "../moodforLove/index.html"+(openid==""?"":"?openid="+openid);
        })
        $("#lynn").on("tap",function(){
            window.location.href = "../liYing/index.html"+(openid==""?"":"?openid="+openid);
        })
        $('#chaonengbao').on('tap',function() {
            window.location.href = '../chaonengbao/index.html'+(openid==""?"":"?openid="+openid);
        })
        $('#list1').on('tap',function(){
            window.location.href = "list1.html"+(openid==""?"":"?openid="+openid);
        })
        $('#list2').on('tap',function(){
            window.location.href = "list2.html"+(openid==""?"":"?openid="+openid);
        })
        $('#list3').on('tap',function(){
            window.location.href = "list3.html"+(openid==""?"":"?openid="+openid);
        })
    }
    function setTab(){
        $('.seek_ul li').removeClass('seek_li');
        $(this).addClass('seek_li');
        $('.seek_jiank').hide();
        $('.seek_jiank').eq($(this).index()).show();

    }
    function setSexFun(){
        var panel_sex = new ebt.panel({
            type:"dataList",
            dataList:[
                {t:"不限",v:"",def:true},
                {t:"帅哥",v:"M"},
                {t:"美女",v:"F"}
            ],
            selectData:function(data){
                $("#sex").val(data.t).attr("data-val",data.v);
            }
        });

        $("#sex")["tap"](function(){
            panel_sex.open();
        });
    }
  /*  function gotoceshi(){
        $('.one_panel_mask').css("zIndex",'1111111');
        $('#cpic-panel-1').css("zIndex",'1111112');
        $('#ceshi').on('tap',function(e){
            $(window).scrollTop($(".seek").offset().top-$(".top_one").height());
            $(".top_one").addClass('top-123');
            $("#top-123").css("height",$(".top_one").height()+'px');
            e.stopPropagation();
            return false;
           /!* console.log($(window).scrollTop())*!/
        });
        $('#guwen').on('tap',function(e){
            $(window).scrollTop($(".container").offset().top-$(".top_one").height());
            $(".top_one").addClass('top-123');
            $("#top-123").css("height",$(".top_one").height()+'px');
            e.stopPropagation();
            return false;
            /!* console.log($(window).scrollTop())*!/
        })
    }*/
    function setCityFun(){
        ebt.exports.datetimePicker({
            eventTrigger:"#city",
            onChange:function(valueObj, value){
                var cityData = valueObj.province.name+">"+valueObj.city.name+">"+valueObj.county.name;
                $("#city").val(cityData).attr("data-val",JSON.stringify(valueObj));
                var json_str=JSON.stringify(cityData);
                if(json_str.length>16){

                    $("#city").val(valueObj.province.name+">"+valueObj.city.name+">").attr("data-val",JSON.stringify(valueObj));
                    $("#county").show();
                    $("#county").val(valueObj.county.name);
                }else{
                    $("#city").val(cityData).attr("data-val",JSON.stringify(valueObj));
                    $("#county").hide();

                }
            }
        });
    }
    function setFunClick(){
        //查找我的保险顾问
        $('.submit').on('tap',submitto);
        //我要找寿险保险产品  tab切换
        $('.seek_ul li').on('tap',setTab);
        //性别选择
        setSexFun();
        //地区选择
        setCityFun();

        imgTab()
    }
    function imgTab(){
        $(".top_img").on("touchstart",function(e){
            if($(this).attr("n")==0){
                $(this).attr("src","img/tabgunwen2.png")
            }
            if($(this).attr("n")==1){
                $(this).attr("src","img/chanping2.png")
            }
            $(".top_img").on("touchend",function(){
                if($(this).attr("n")==0){
                    $(this).attr("src","img/tabgunwen1.png"); $(window).scrollTop($(".container").offset().top-$(".top_one").height());
                    $(".top_one").addClass('top-123');
                    $("#top-123").css("height",$(".top_one").height()+'px');

                }
                if($(this).attr("n")==1){
                    $(this).attr("src","img/chanping1.png");
                    $(window).scrollTop($(".seek").offset().top-$(".top_one").height());
                    $(".top_one").addClass('top-123');
                    $("#top-123").css("height",$(".top_one").height()+'px');
                }
                $('.one_panel_mask').css("zIndex",'1111111');
                $('#cpic-panel-1').css("zIndex",'1111112');
                /*$('#ceshi').on('tap',function(){

                    /!* console.log($(window).scrollTop())*!/
                });
                $('#guwen').on('tap',function(){


                    /!* console.log($(window).scrollTop())*!/
                })*/
            })

            return false;
        })
    }

    function initVali() {
        var _form = {
            methods: {
                "city": {
                    required: "required"
                }
            },
            errors: {
                "city": {
                    required: "地区不能为空"
                }
            }
        };
        return ebt.valiformdata.initValiData(_form);
    }
    //部署
    function setOM(){
        var obj = ebt.omObject(gchannel,"导购首页");
        if(obj == "") return;
        ebt.omniture.t(obj);
    }
    init();
});