var ebt = ebt || {};
/* ============= header & footer ==============*/
(function($){
	this.getQueryString = function(names, urls,isdecodeuri) {
		urls = urls || window.location.href;
		urls = urls && urls.indexOf("?") > -1 ? urls.substring(urls.indexOf("?") + 1) : "";
		var reg = new RegExp("(^|&)" + names + "=([^&]*)(&|$)", "i");
		var r = urls ? urls.match(reg) : window.location.search.substr(1).match(reg);
		if (r != null && r[2] != "") {
			//var ms = r[2].match(/(\<)|(\>)|(%3C)|(%3E)/g);
			//if (ms && ms.length >= 4) {
			//	//如果检测到有2对及以上开始和结束尖括号
			//	r[2] = r[2].replace(/(\<)|(%3C)/g, "");
			//}
			if(isdecodeuri){
				return decodeURI(r[2].replace(/%3C/g,'&lt').replace(/%3E/g,'&gt').replace(/</g,'&lt').replace(/>/g,'&gt'));
			}
			return unescape(r[2].replace(/%3C/g,'&lt').replace(/%3E/g,'&gt').replace(/</g,'&lt').replace(/>/g,'&gt'));
		}
		return null;
	};
	this.gchannel = function(){
		var gchannel = ebt.getQueryString("gchannel");
		if(gchannel){
			if(gchannel.match(/MicroMessenger/i)){
				gchannel = "W"
			}else{
				gchannel = gchannel;
			}
		}else{
			if(window.localStorage.getItem("gchannel")){
				gchannel = window.localStorage.getItem("gchannel");
			}else{
				if(navigator.appVersion.match(/MicroMessenger/i)){
					//微信
					gchannel="W";
				}else{
					//其他 默认为触屏版
					gchannel="T";
				}
			}
		}
		return gchannel;
	};
	this.addHeaderHtml = function (){
		var _gchannel = ebt.gchannel();
		var _elements = "";
		var _title = "";
		if(_gchannel == "T"){   //若为触屏版则添加上下样式
			if(!$("#tTitle").val()){
				_title = window.document.title;
			}else{
				_title = $("#tTitle").val();
			}

			var	_header = '<header style="width: 100%; overflow: hidden; position: relative; padding-top: 0.75em; padding-bottom: 0.875em; border-bottom: 1px solid #c6c6c6; background: #e9e9e9; ">' +
				'<a href="javascript:history.go(-1)" style="position: absolute; z-index: 3; top: 44%; left: 1em; margin-top: -0.64em;-webkit-transform: scale(0.6);-moz-transform: scale(0.6);-ms-transform: scale(0.6);-o-transform: scale(0.6);transform: scale(0.6);"><img src="http://m.ecpic.com.cn/images/icon_back01.png" style="width:80%;"></a>' +
				'<h1 style="width: 100%; overflow: hidden; position: relative; font-weight: normal; text-align: center; font-size: 1em; color: #1876e0;">'+_title+'</h1>' +
				'<a href="http://m.ecpic.com.cn/index.html" style="position: absolute; width: 1.28em; height: 1.28em; z-index: 3; top: 50%; right: 1em; margin-top: -0.64em;"><img src="http://m.ecpic.com.cn/images/icon_home01.png" style="width:80%;"></a>' +
				'</header>';
			if($("#tTypeShow").val() == 0){
				_header = '';
			}
			if($("#tTypeShow").val() == 6){
				_header = '<header style="width: 100%; overflow: hidden; position: relative; padding-top: 0.75em; padding-bottom: 0.875em; border-bottom: 1px solid #c6c6c6; background: #e9e9e9; ">' +
				'<h1 style="width: 100%; overflow: hidden; position: relative; font-weight: normal; text-align: center; font-size: 1em; color: #1876e0;">'+_title+'</h1>' +
				'<a href="http://m.ecpic.com.cn/index.html" style="position: absolute; width: 1.28em; height: 1.28em; z-index: 3; top: 50%; right: 1em; margin-top: -0.64em;"><img src="http://m.ecpic.com.cn/images/icon_home01.png" style="width:80%;"></a>' +
				'</header>';
			}
			if($("#tTypeShow").val() == 5){
				_header = '';
			}
			var _nav = '';
			var _footer = '<footer style="width: 100%; overflow: hidden; background: #e2e3e2; margin-top: 0.25em; font-size: .8rem; ">'+
				'<div style="width: 100%; overflow: hidden; padding-top: 0.75em; padding-bottom: 0.125em;">'+
				'<span style="display: block; width: 50%; text-align: center; float: left; color: #1876e0; border-right: 1px solid #1876e0;padding-left: 1rem;">当前为触屏版</span>'+
				'<a href="http://www.ecpic.com.cn/?fr=3w" style="display: block; width: 50%; text-align: center; float: left; color: #1876e0;padding-right: 1rem;">切换至电脑版</a></div>'+
				'<div style="width: 100%; text-align: center; padding: 0.3em 0;">'+
				'<span style="color: #777; font-size: 0.75em;">Copyright © China Pacific Insurance(group) Co.,Ltd.</span></div></footer>';
			if($("#tTypeShow").val() == 5){
				_footer = '';
			}
			switch ($("#tTypeShow").val()) {
				case '0':
					_nav = '';
					break;
				case '1':
					_nav = '';
					break;
				case '2':  //自助服务
					_nav = '<nav style="width: 100%; overflow: hidden; background: #f6f6f6; border-top: 1px solid #fff; padding-top: 0.406em; padding-bottom: 0.375em; border-bottom: 1px solid #c6c6c6; ">' +
						'<a href="http://m.ecpic.com.cn/mobile_cpic/bxindex.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #e2e3e2; padding: 0.875em 0; border-bottom: 1px solid #e2e3e2; border-right: 1px solid #c3c3c3;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">购买保险</span></a>' +
						'<a href="http://m.ecpic.com.cn/mobile_cpic/zzfw.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #fff; padding: 0.563em 0 0.875em 0; border-bottom: 1px solid #e2e3e2; border-top: 0.3215em solid #4692e4;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">自助服务</span></a>' +
						'<a href="http://m.ecpic.com.cn/app/v4/user/index.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #e2e3e2; padding: 0.875em 0; border-bottom: 1px solid #e2e3e2;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">用户中心</span></a></nav>';
					break;
				case '3':  //用户中心
					_nav = '<nav style="width: 100%; overflow: hidden; background: #f6f6f6; border-top: 1px solid #fff; padding-top: 0.406em; padding-bottom: 0.375em; border-bottom: 1px solid #c6c6c6; ">' +
						'<a href="http://m.ecpic.com.cn/mobile_cpic/bxindex.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #e2e3e2; padding: 0.875em 0; border-bottom: 1px solid #e2e3e2;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">购买保险</span></a>' +
						'<a href="http://m.ecpic.com.cn/mobile_cpic/zzfw.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #e2e3e2; padding: 0.875em 0; border-bottom: 1px solid #e2e3e2; border-right: 1px solid #c3c3c3;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">自助服务</span></a>' +
						'<a href="http://m.ecpic.com.cn/app/v4/user/index.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #fff; padding: 0.563em 0 0.875em 0; border-bottom: 1px solid #e2e3e2; border-top: 0.3215em solid #4692e4;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">用户中心</span></a></nav>';
					break;
				case '4':  //购买保险
					_nav = '<nav style="width: 100%; overflow: hidden; background: #f6f6f6; border-top: 1px solid #fff; padding-top: 0.406em; padding-bottom: 0.375em; border-bottom: 1px solid #c6c6c6; ">' +
						'<a href="http://m.ecpic.com.cn/mobile_cpic/bxindex.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #fff; padding: 0.563em 0 0.875em 0; border-bottom: 1px solid #e2e3e2; border-top: 0.3215em solid #4692e4;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">购买保险</span></a>' +
						'<a href="http://m.ecpic.com.cn/mobile_cpic/zzfw.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #e2e3e2; padding: 0.875em 0; border-bottom: 1px solid #e2e3e2; border-right: 1px solid #c3c3c3;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">自助服务</span></a>' +
						'<a href="http://m.ecpic.com.cn/app/v4/user/index.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #e2e3e2; padding: 0.875em 0; border-bottom: 1px solid #e2e3e2;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">用户中心</span></a></nav>';
					break;
				case '5':  //寿险
					_nav = '';
					break;
				default:   //自助服务
					_nav = '<nav style="width: 100%; overflow: hidden; background: #f6f6f6; border-top: 1px solid #fff; padding-top: 0.406em; padding-bottom: 0.375em; border-bottom: 1px solid #c6c6c6; ">' +
						'<a href="http://m.ecpic.com.cn/mobile_cpic/bxindex.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #e2e3e2; padding: 0.875em 0; border-bottom: 1px solid #e2e3e2; border-right: 1px solid #c3c3c3;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">购买保险</span></a>' +
						'<a href="http://m.ecpic.com.cn/mobile_cpic/zzfw.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #fff; padding: 0.563em 0 0.875em 0; border-bottom: 1px solid #e2e3e2; border-top: 0.3215em solid #4692e4;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">自助服务</span></a>' +
						'<a href="http://m.ecpic.com.cn/app/v4/user/index.html" style="width: 33.33%; display: block; float: left; text-align: center; background: #e2e3e2; padding: 0.875em 0; border-bottom: 1px solid #e2e3e2;">' +
						'<span style="color: #1a77e0; font-size: 0.938em;">用户中心</span></a></nav>';
					break;
			}
			/*$("body").prepend(_nav);*/
			$("body").prepend(_header);
			var _href = window.location.href;
			if(_href.indexOf("http://m.ecpic.com.cn/index.shtml")<0 &&_href .indexOf("/bxindex.html")<0){
				_footer = "";
				$("header").css("background","#ffffff");
			}
			$("body").append(_footer);
			var mar = "0.25em";
			if($(window).height() > $("body").height()){
				mar = (($(window).height() - $("body").height()))+ "px"
				$("footer").css("margin-top",mar);
			}
		}
	}
}).call(ebt,Zepto);

