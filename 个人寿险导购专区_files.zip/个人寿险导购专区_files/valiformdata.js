var ebt = ebt || {};

(function(N, $) {
	/**
	 * 简易表单验证 在需要验证的输入框的class当中添加formCheck值，代表当前输入框需要进行表单验证。
	 * 对于验证的格式可以在class当中添加methods当中已经定义的值， class中的值必须使用空格分开。示例（校验为必填且格式为日期格式）：
	 * <input type="text" class="formCheck required date"/>
	 */
	N.valiformdata = (function() {
		var methods = {};

		/**
		 * 返回空字符串 校验通过
		 * 返回非空字符串 校验不通过
		 */

		/**
		 * 验证是否为空
		 */
		methods.required = function(p) {
			return p.value.trim() !== "" ? "" : p.msg;
		};
		/**
		 * 验证日期
		 */
		methods.date = function(p) {
			return (/^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$/.test(p.value)) ? "" : p.msg;
		};
		/**
		 * 验证数字,可为负数以及允许存在小数点
		 */
		methods.number = function(p) {
			return (/^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/.test(p.value)) ? "" : p.msg;
		};
		/*
		* 验证数字，大于零的正整数
		* */
		methods.number1 = function(p){
			var _val = p.value;
			if((!/^[0-9]*$/.test(_val))||(!/^[^0]/.test(_val))||_val <= 0){
				return p.msg;
			}
			return "";
		};
		/*
		 * 验证数字，大于等于零的正整数
		 * */
		methods.number2 = function(p){
			var _val = p.value;
			if((!/^[0-9]*$/.test(_val))||_val < 0){
				return p.msg;
			}
			return "";
		};
		/**
		 * 验证邮箱地址
		 */
		methods.email = function(p) {
			return (/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i
				.test(p.value) || !p.value) ? "" : p.msg;
		};
		/**
		 * 验证手机号码
		 */
		methods.mobile = function(p) {
			return (/^(1)\d{10}$/.test(p.value.trim()) || !p.value) ? "" : p.msg;
		};
		/**
		 * 验证手机号码
		 */
		methods.mobile2 = function(p) {
			return (/^1[3|4|5|8|7][0-9]\d{8}$/.test(p.value.trim()) || !p.value) ? "" : p.msg;
		};
		/**
		 * 验证邮箱地址或者手机号码
		 */
		methods.emailormobile = function(p) {
			return (/^(13|14|15|18)\d{9}$|^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/
				.test(p.value)) ? "" : p.msg;
		};
		/**
		 * 验证手机号码或者座机号码
		 */
		methods.phoneormobile = function(p) {
			return (/(^\(?(0\d{2,3}-?)\)?\d{7,8}$)|(^(13|14|15|18|17)\d{9}$)/
				.test(p.value.trim())) ? "" : p.msg;//
		};
		/**
		 * 蹭网险领取奖品时专用验证,验证手机号段
		 */
		methods.ebtphoneormobile = function(p) {
			return (/^1((3[0-2 4-9])|(47)|(50|51|52|55|56|57|58|59)|(70|76|78)|(8[2-8]))\d{8}$/
				.test(p.value.trim())) ? "" : p.msg;
		};
		/**
		 * 验证只能为字母和中文
		 */
		methods.string = function(p) {
			return (/^[a-zA-Z\u4E00-\u9FA5]+$/.test(p.value) || !p.value) ? "" : p.msg;
		};
		//
		methods.licenseNo = function(p) {
			return (/(^[\u4E00-\u9FA5]{1}[A-Z0-9]{6}$)|(^[A-Z]{2}[A-Z0-9]{2}[A-Z0-9\u4E00-\u9FA5]{1}[A-Z0-9]{4}$)|(^[\u4E00-\u9FA5]{1}[A-Z0-9]{5}[挂学警军港澳]{1}$)|(^[A-Z]{2}[0-9]{5}$)|(^(08|38){1}[A-Z0-9]{4}[A-Z0-9挂学警军港澳]{1}$)/
				.test(p.value.trim())) ? "" : p.msg;
		};
		/**
		 * 验证中文
		 */
		methods.chineseChracter = function(p) {
			return (/^[\u4e00-\u9fa5]+$/.test(p.value)) ? "" : p.msg;
		};
		/**
		 * 验证身份证号码
		 */
		methods.idcard = function(p) {
			return ((checkIdcard(p.value.trim()) == "验证通过!") || !p.value) ? "" : p.msg;
		};
		/*
		* 验证其它证件号码,"2":"护照","4":"驾照","5":"其他"*/
		methods.idcardOther = function(p) {
			var rtn = p.value.length>18;
			if(rtn) return p.msg;

			rtn = /^[0-9a-zA-Z]+$/.test(p.value) ? "" : p.msg;//数字 字母
			if(rtn!=="")return rtn;

			rtn = /^([\s]){1,18}$/.test(p.value);//含有空格
			if(rtn) return p.msg;

			return "";
		};
		/*验证 军官证
		 *军官证号检核标准：*字第+大于等于4个字符（*代表任意内容，军官证总长度不超过30个字符）
		* 晋消字第124
		* */
		methods.idcardOfficer = function(p) {
			var rtn = p.value.replace(/[^\x00-\xff]/g,"01").length>30;
			if(rtn) return p.msg;

			for(var j=1;j< p.value.length;j++){
				if(p.value.substr(j,2) != "字第")continue;
				if(!(/^[0-9]\d{3,}$/.test(p.value.substr(j+2,p.value.length-j-2))))continue;
				if(!(/^[\u4e00-\u9fa5]+$/.test(p.value.substr(0,j))))continue;//验证中文
				return "";
			}
			return p.msg;
		};
		/**
		 * 验证地址
		 */
		methods.address = function(p) {
			return (/^[0-9a-zA-Z\u4E00-\u9FA5]+$/.test(p.value) || !p.value) ? "" : p.msg;
		};
		/**
		 * 邮政编码校验
		 */
		methods.postCode = function(p) {
			return (/^\d{6}$/.test(p.value) || !p.value) ? "" : p.msg;
		};
		/**
		 * 验证座机号码
		 */
		methods.telephone = function(p) {
			return (/^\(?(0\d{2,3}-?)?\)?\d{7,8}$/.test(p.value) || !p.value) ? "" : p.msg;
		};
		/**
		 * 保单号
		 */
		methods.policyNo = function(p) {
			return /^[A-Za-z]+[0-9]+[A-Za-z0-9]*$|^[0-9]+[A-Za-z]+[A-Za-z0-9]*$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 验证密码
		 */
		methods.checkPwd = function(p) {
			return (checkPwd(p.value) === true) ? "" : p.msg;
		};
		/**
		 * 验证最小长度
		 */
		methods.minLength = function(p) {
			return (p.value.length >= p.params.minLength) ? "" : p.msg;
		};
		/**
		 * 验证最大长度
		 */
		methods.maxLength = function(p) {
			return (p.value.length <= p.params.maxLength) ? "" : p.msg;
		};
		/**
		 * 验证登录名称
		 */
		methods.loginName = function(p) {
			return (/^[0-9a-zA-Z\_\-\u4e00-\u9fa5]+$/.test(p.value) || !p.value) ? "" : p.msg;
		};
		/**
		 * 验证长度范围
		 */
		methods.lengthFromTo = function(p) {
			var reg = new RegExp("^.{" + p.params.from + "," + p.params.to + "}$");
			return reg.test(p.value) ? "" : p.msg;
		};
		/**
		 * 验证cpic中文
		 */
		methods.cpicChineseChracter = function(p) {
			return (/^[\u4e00-\u9fa5|\u25cf|\u2022|%b7]+$/.test(p.value)) ? "" : p.msg;
		};
		/**
		 * 和另外一个值做比对,一般用作确认密码
		 */
		methods.consistentTo = function(p) {
			var to = $(p.params.to);
			return p.value === to[0].value ? "" : p.msg;
		};
		/**
		 * 数字或者字母大写
		 */
		methods.numberUppLetter = function(p) {
			var reg = /^[A-Z0-9]+$/;
			return reg.test(p.value) ? "" : p.msg;
		};
		/**
		 * 复杂度校验
		 */
		methods.complex = function(p) {
			var reg = /[A-Za-z].*[0-9]|[0-9].*[A-Za-z]/;
			return reg.test(p.value) ? "" : p.msg;
		};
		/**
		 * 数值大小的范围检测
		 */
		methods.sumFromTo = function(p) {
			//数值大小的范围检测   (from,to]
			var From = p.params ? (p.params.from || 0) : 0,
				To = p.params ? (p.params.to || 100) : 100,
				flag_L = p.params ? (p.params.flag_L || false) : false,
				flag_R = p.params ? (p.params.flag_R || false) : false,
				num = Number(p.value);
			if (From == "min" && To != "max") {
				//（负无穷，M)
				if (flag_R) {
					return (num > To) ? p.msg : "";
				} else {
					return (num >= To) ? p.msg : "";
				}
				// return flag_R?((num>To)? p.msg :""):((num>=To)? p.msg :"");

			} else if (From != "min" && To == "max") {
				//(M,正无穷)
				return flag_L ? ((num < From) ? p.msg : "") : ((num <= From) ? p.msg : "");

			} else if (From != "min" && To != "max") {
				// (m,n)
				if (flag_L && flag_R) {
					return (num < From || num > To) ? p.msg : "";
				} else if (flag_L && !flag_R) {
					return (num < From || num >= To) ? p.msg : "";
				} else if (!flag_L && flag_R) {
					return (num <= From || num > To) ? p.msg : "";
				} else if (!(flag_L || flag_R)) {
					return (num <= From || num >= To) ? p.msg : "";
				}
			}

		};
		/**
		 * 正整数检测
		 */
		methods.positiveNumber = function(p) {
			return /^[1-9]\d*$/.test(Number(p.value)) ? "" : p.msg;
		};

		/*以下为e宝通验证规则搬迁过来*/
		/**
		 * 用户名
		 */
		methods.username = function(p) {
			//return /^([\u4E00-\uFA29]|[\uE7C7-\uE7F3]|[0-9a-zA-Z])*$/.test(p.value) ? "" : p.msg;
			var res = "";
			if(p.value.length===1){
				res =  /^([\s]){1,1}$/.test(p.value);//只有一个空格
				if(res){
					return p.msg;
				}
			}
			res = /^([a-zA-Z\u4e00-\u9fa5\s]){0,20}$/.test(p.value);//"姓名只能含汉字、字母、符号中的空格，且最多容许20个字符。";
			if (!res) {
				return p.msg;
			}

			if(p.value.replace(/[^\x00-\xff]/g, 'xx').length>20){
				return p.msg;
			}

			res =  /^((?! {2,}).)+$/.test(p.value);//"空格不能连续2个及以上";
			if (!res) {
				return p.msg;
			}
			return "";
		};
		
		/**
		 * 客户姓名,2016-7-22，按照客户信息逻辑控制标准20160704版规则编写
		 1、姓名字段不能为空
		 2、姓名字段中不允许含有数字\标点符号(“•”除外），且首位与末位不能为空格。姓名为汉字的，间隔符只允许使用“·”。
		 3、姓名字段中不允许含有汉字又同时含有字母
		 4、姓名字段长度不小于2个字符
		 5、姓名字段不允许长度超过25个汉字，姓名全部由字母或空格组成的不在此条判定规则之列。
		 */
		methods.customerName= function(p){
			var _t=p.value.replace(/\s/g,"");//剔除所有空格
			if(_t==""){
				return p.msg+"不能为空";
			}
			if(!/^[a-z|A-Z|\u4e00-\u9fa5|\u25cf|\u2022|·|\s]+$/.test(p.value)){
				return p.msg+"只能含汉字、字母、“•”，最多允许输入25个汉字";
			}
			if(/(^\s|\s$)/.test(p.value)){
				return p.msg+"输入错误";
			}
			if(/\s\s\s*/.test(p.value)){
				return p.msg+"输入错误";
			}
			if(_t.length<2){
				return p.msg+"输入错误";
			}
			
			
			/*if(/^[a-z|A-Z]/.test(p.value)){
				if (/^[\u4e00-\u9fa5|\u25cf|\u202]+$/.test(p.value)) {}
				return p.msg+"不允许含有英文和汉字";
			}*/
			if(/^[·|•]+|[·|•]+$/.test(p.value)){
					return p.msg+"输入错误";
				}
			if(/[a-zA-Z]/.test(p.value)){
				if(/[\u4e00-\u9fa5]/.test(p.value)){
					return p.msg+"输入错误";
				}if(/[·|•]/.test(p.value)){
					return p.msg+"输入错误";
				}
			}

			if(/[\u4e00-\u9fa5|\u25cf|\u2022]/.test(p.value)){

				if(/\s/.test(p.value)){
					return p.msg+"输入错误";
				}
				if (/•/.test(p.value) ) {
					return p.msg+"仅支持中文格式的“·”,请切换至其它输入法";
				}
				if(!/^[\u4e00-\u9fa5|\u25cf|\u2022|·]+$/.test(p.value) && !/^[a-zA-Z|·|•]+$/.test(p.value)){
					return p.msg+"输入错误";
				}
				if(/^[\u2022|·]*[\u2022|·]+$/.test(p.value)){
					return p.msg+"输入错误";
				}
				if(/^[\u4e00-\u9fa5]/.test(p.value) && _t.length>25){
					return p.msg+"只能含汉字、字母、“•”，最多允许输入25个汉字";
				}

			}
			return "";
		};

		/*姓名拼音须以英文大写拼写，以空格分隔*/
		methods.pinyinName = function(p){
			var pinyin = p.value.toUpperCase();
			return /^[A-Z]+\s{1}[A-z|·|•]+(\s{1}[A-Z|·|•]+)*\s?$/.test(pinyin)? "" : p.msg;
		};
		/**
		 * 字母
		 */
		methods.letter = function(p) {
			return /^[a-zA-Z]+$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 数字和字母
		 */
		methods.numberletter = function(p) {
			return /^[0-9a-zA-Z]+$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 航班号(英文字母和数字的组合)
		 */
		methods.flightNum = function(p) {
			//return /^[0-9a-zA-Z]+$/.test(p.value) ? "" : p.msg;

			var msg = "";
			//只包含数字、字母
			msg = /^[0-9a-zA-Z]+$/.test(p.value) ? "" : p.msg;
			if(msg!=="") return p.msg;

			//只包含数字
			msg = /^[0-9]+$/.test(p.value) ? "" : p.msg;
			if(msg==="") return p.msg;

			//只包含字母
			msg = /^[a-zA-Z]+$/.test(p.value) ? "" : p.msg;
			if(msg==="") return p.msg;

			//最大长度10
			if(p.value.replace(/[^\x00-\xff]/g, 'xx').length>10){
				return p.msg;
			}
			return "";
		};
		/**
		 * 非全数字和全字母
		 */
		methods.notNumberAndZM = function(p) {
			var msg = "";
			//只包含数字
			msg = /^[0-9]+$/.test(p.value) ? "" : p.msg;
			if(msg==="") return p.msg;

			//只包含字母
			msg = /^[a-zA-Z]+$/.test(p.value) ? "" : p.msg;
			if(msg==="") return p.msg;
			return "";
		};


		/**
		 * 银行卡正则
		 */
		methods.bankCard = function(p) {
			return /^[\d]{16,19}$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 持卡人 （汉字、字母、_、数字）
		 */
		methods.cardHolder = function(p) {
			return /^[a-zA-Z0-9_\u4e00-\u9fa5]*$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 车牌号
		 */
		methods.carNumber = function(p) {
			return /^[\u4e00-\u9fa5]{1}[A-Z]{1}[A-Z0-9]{5}$/.test(p.value.trim().toUpperCase()) ? "" : p.msg;
		};
		/*
		* 车架号
		* */
		methods.vin = function(p){
			return /^[0-9a-zA-Z]{17}$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 寿险保单号
		 */
		methods.lifePolicyNo = function(p) {
			return /^[0-9a-zA-Z]{15,20}$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 报案号
		 */
		methods.BaoanNo = function(p) {
			return /^[0-9a-zA-Z]{15}$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 驾驶证号
		 */
		methods.driverLiscenseNo = function(p) {
			return /^\w+$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 驾驶证号
		 */
		methods.driverLiscenseNo = function(p) {
			return /^\w+$/.test(p.value) ? "" : p.msg;
		};
		/**
		 * 特殊字符验证
		 */
		methods.specialflag = function(p) {
			return /[@._-]/.test(p.value) ? "" : p.msg;
		};
		/*e宝通验证规则搬迁 end*/

		/*汉字、英文字母或数字*/
		methods.site = function(p){
			return /^([\u4E00-\uFA29]|[\uE7C7-\uE7F3]|[0-9a-zA-Z])*$/.test(p.value) ? "" : p.msg;
		};

		return {

			checkMethod:function(p){
				p.value=p.value.replace(/\r/g, "");
				p.params=p.params||[];
				var result="";

				if(Array.isArray(p.name)){
					for(var m=0;m<p.name.length;m++)
					{
						result = methods[p.name[m]]({
							value:p.value,
							msg:p.error[m],
							params:p.params[m]
						});
						result=result||"";
						if (result != "") {
							return result;
						}
					}
				}else{
					result=methods[p.name]({
						value:p.value.replace(/\r/g, ""),
						msg:p.error,
						params:p.params
					});
				}
				return result;
			},
			/**
			 * 校验所有表单
			 * @param selector
			 * @param callBack
			 * @returns {boolean}
			 */
			check: function(selector, callBack) {
				if (!selector) {
					selector = $("[cpic-validata-enable='true']");
				}
				var params = params || {};
				var pass = true,
					_methods, _errors;
				selector.each(function() {
					var _this = $(this);
					_methods = _this.attr("cpic-validata-methods").split("&") || [];
					_errors = _this.attr("cpic-validata-errors").split("&") || [];
					for (var m = 0; m < _methods.length; m++) {
						var methodName = _methods[m].split(":");
						if (!$.isFunction(methods[methodName[0]])) {
							continue;
						}
						var result = methods[methodName[0]]({
							value: _this.val().replace(/\r/g, ""),
							msg: _errors[m],
							params: (methodName.length > 1 ? JSON.parse(methodName.splice(1).join(":")) : {})
						});
						result = result || "";
						if (result !== "") {
							if ($.isFunction(callBack)) {
								callBack(result, _this.attr("id"), methodName[0]);
							}
							pass = false;
							return pass;
						}
					}
				});
				return pass;
			},
			/**
			 * 校验单个表单
			 * @param node
			 * @param callBack
			 * @param allCall
			 * @returns {boolean}
			 */
			checkSingleNode: function(node, callBack, allCall) {
				//allCall add 2014-12-30 控制是否验证通过也调用回调函数
				allCall = allCall || false;
				var pass = true;
				if (node) {
					var _this = node;
					_methods = _this.attr("cpic-validata-methods").split("&") || [];
					_errors = _this.attr("cpic-validata-errors").split("&") || [];
					for (var m = 0; m < _methods.length; m++) {
						var methodName = _methods[m].split(":");
						if (!$.isFunction(methods[methodName[0]])) {
							continue;
						}
						var result = methods[methodName[0]]({
							value: _this.val().replace(/\r/g, ""),
							msg: _errors[m],
							params: (methodName.length > 1 ? JSON.parse(methodName.splice(1).join(":")) : {})
						});
						result = result || "";
						if (result !== "") {
							if ($.isFunction(callBack)) {
								callBack(result, _this.attr("id"), methodName[0]);
							}
							pass = false;
							return pass;
						}
						if (allCall) {
							if ($.isFunction(callBack)) {
								callBack(result, _this.attr("id"), methodName[0]);
							}
						}
					}
				}
				return pass;
			},
			/**
			 * 初始化校验规则
			 * @param params
			 */
			initValiData: function(params) {
				var _methods = params.methods || {},
					_errors = params.errors || {};
				for (var m in _methods) {
					var _this = $("#" + m),
						ms = [],
						es = [];
					for (var md in _methods[m]) {
						if (typeof _methods[m][md] == 'object') {
							ms.push(md + ":" + JSON.stringify(_methods[m][md]));
						} else {
							ms.push(md);
						}
						es.push(_errors[m][md]);
					}
					_this.attr("cpic-validata-methods", ms.join("&"))
						.attr("cpic-validata-errors", es.join("&"))
						.attr("cpic-validata-enable", "true");
				}
			},
			checkIdcardOfficer:function(p,callBack,msg){
				var result = methods.idcardOfficer(p);
				if ($.isFunction(callBack)) {
					callBack(result);
				}
				return result;
			},
			checkidcard:function(p,callBack,msg){
				msg = msg||"您";
				var result = "";
				if(methods.required(p)!==""){
					result = "请输入"+msg+"的身份证号！";
				}else if(methods.idcard(p)!==""){
					result = "请输入正确的身份证号码！";//"您输入的身份证号有误，请重新输入！";
				}
				if ($.isFunction(callBack)) {
					callBack(result);
				}
				return result;
			},
			checkBaoanNo:function(p,callBack){
				var result = "";
				if(methods.required(p)!==""){
					result = "请输入您的报案号！";
				}else if(methods.BaoanNo(p)!==""){
					result = "请输入由字母或数字组成长度为15位的报案号！";
				}
				if ($.isFunction(callBack)) {
					callBack(result);
				}
				return result;
			},
			checkPolicyNo:function(p,callBack){
				var result = "";
				if(methods.required(p)!==""){
					result = "请输入保单号！";
				}else if(methods.lengthFromTo({params:{from:20,to:20},value: p.value})!==""){
					result = "保单号必须由20位英文或数字组成！";
				}else if(methods.policyNo(p)!==""){
					result = "保单号必须由20位英文或数字组成！";
				}
				if ($.isFunction(callBack)) {
					callBack(result);
				}
				return result;
			},
			checkUsername:function(p,callBack,msg){
				msg = msg||"";
				var result = "";
				if(methods.required(p)!==""){
					result = "请输入"+msg+"姓名！";
				}else if(methods.username(p)!==""){
					result = msg+"姓名只能含汉字、字母、符号中的空格，且最多容许20个字符。";
				}
				if ($.isFunction(callBack)) {
					callBack(result);
				}
				return result;
			},
			//证件类型为非身份证，校验规则：最大长度为18位英文字母或数字，不可为空，不支持输入空格。
			checkOtherCardNum:function(p,callBack){
				var result = "";
				if(p.value.length>18){
					result = "请输入正确的证件号码";
				}else if(methods.numberletter(p)!==""){//数字 字母
					result = "请输入正确的证件号码";
				}else if( /^([\s]){1,18}$/.test(p.value)){//含有空格
					result = "请输入正确的证件号码";
				}

				if ($.isFunction(callBack)) {
					callBack(result);
				}
				return result;
			}
		};
	})();

	// 验证身份证
	function checkIdcard(idcard) {
		idcard = idcard.toUpperCase();
		var Errors = new Array("验证通过!", "身份证号码位数不对!", "身份证号码出生日期超出范围或含有非法字符!",
			"身份证号码校验错误!", "身份证地区非法!");
		var area = {
			11: "北京",
			12: "天津",
			13: "河北",
			14: "山西",
			15: "内蒙古",
			21: "辽宁",
			22: "吉林",
			23: "黑龙江",
			31: "上海",
			32: "江苏",
			33: "浙江",
			34: "安徽",
			35: "福建",
			36: "江西",
			37: "山东",
			41: "河南",
			42: "湖北",
			43: "湖南",
			44: "广东",
			45: "广西",
			46: "海南",
			50: "重庆",
			51: "四川",
			52: "贵州",
			53: "云南",
			54: "西藏",
			61: "陕西",
			62: "甘肃",
			63: "青海",
			64: "宁夏",
			65: "新疆",
			71: "台湾",
			81: "香港",
			82: "澳门",
			91: "国外"
		};
		var Y, JYM;
		var S, M;
		var idcard_array = [];
		idcard_array = idcard.split("");
		if (area[parseInt(idcard.substr(0, 2))] == null)
			return Errors[4];
		switch (idcard.length) {
			case 15:
				if ((parseInt(idcard.substr(6, 2)) + 1900) % 4 == 0 || ((parseInt(idcard.substr(6, 2)) + 1900) % 100 == 0 && (parseInt(idcard
						.substr(6, 2)) + 1900) % 4 == 0)) {
					ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/; // 测试出生日期的合法性
				} else {
					ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/; // 测试出生日期的合法性
				}
				if (ereg.test(idcard))
					return Errors[0];
				else
					return Errors[2];
				break;
			case 18:
				if (parseInt(idcard.substr(6, 4)) % 4 == 0 || (parseInt(idcard.substr(6, 4)) % 100 == 0 && parseInt(idcard
						.substr(6, 4)) % 4 == 0)) {
					ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$/; // 闰年出生日期的合法性正则表达式
					eregNow = /^[1-9][0-9]{5}20[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$/; // 闰年出生日期的合法性正则表达式
				} else {
					ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$/; // 平年出生日期的合法性正则表达式
					eregNow = /^[1-9][0-9]{5}20[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$/; // 平年出生日期的合法性正则表达式
				}
				if (ereg.test(idcard) || eregNow.test(idcard)) {
					S = (parseInt(idcard_array[0]) + parseInt(idcard_array[10])) * 7 + (parseInt(idcard_array[1]) + parseInt(idcard_array[11])) * 9 + (parseInt(idcard_array[2]) + parseInt(idcard_array[12])) * 10 + (parseInt(idcard_array[3]) + parseInt(idcard_array[13])) * 5 + (parseInt(idcard_array[4]) + parseInt(idcard_array[14])) * 8 + (parseInt(idcard_array[5]) + parseInt(idcard_array[15])) * 4 + (parseInt(idcard_array[6]) + parseInt(idcard_array[16])) * 2 + parseInt(idcard_array[7]) * 1 + parseInt(idcard_array[8]) * 6 + parseInt(idcard_array[9]) * 3;
					Y = S % 11;
					M = "F";
					JYM = "10X98765432";
					M = JYM.substr(Y, 1);
					if (M == idcard_array[17])
						return Errors[0];
					else
						return Errors[3];
				} else
					return Errors[2];
				break;
			default:
				return Errors[1];
				break;
		}

	}

	// 验证密码
	function checkPwd(value) {
		if (value == '') {
			return false;
		}
		var _reg = "^[\\w@\\-\\.]{6,16}$";
		var re = new RegExp(_reg);
		if (!re.test(value)) {
			return false;
		}
		return true;
	}
})(ebt, Zepto);