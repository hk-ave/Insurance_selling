﻿/**
 * Created by kui.yang on 15/3/26.
 */

/**
 * 全局变量ebt，所有公用方法全部归到此变量中去
 */
function RSAKeyPair(encryptionExponent,decryptionExponent,modulus){this.e=biFromHex(encryptionExponent);this.d=biFromHex(decryptionExponent);this.m=biFromHex(modulus);this.chunkSize=2*biHighIndex(this.m);this.radix=16;this.barrett=new BarrettMu(this.m)}function twoDigit(n){return(n<10?"0":"")+String(n)}function encryptedString(key,s){var a=new Array();var sl=s.length;var i=0;while(i<sl){a[i]=s.charCodeAt(i);i++}while(a.length%key.chunkSize!=0){a[i++]=0}var al=a.length;var result="";var j,k,block;for(i=0;i<al;i+=key.chunkSize){block=new BigInt();j=0;for(k=i;k<i+key.chunkSize;++j){block.digits[j]=a[k++];block.digits[j]+=a[k++]<<8}var crypt=key.barrett.powMod(block,key.e);var text=key.radix==16?biToHex(crypt):biToString(crypt,key.radix);result+=text+" "}return result.substring(0,result.length-1)}function decryptedString(key,s){var blocks=s.split(" ");var result="";var i,j,block;for(i=0;i<blocks.length;++i){var bi;if(key.radix==16){bi=biFromHex(blocks[i])}else{bi=biFromString(blocks[i],key.radix)}block=key.barrett.powMod(bi,key.d);for(j=0;j<=biHighIndex(block);++j){result+=String.fromCharCode(block.digits[j]&255,block.digits[j]>>8)}}if(result.charCodeAt(result.length-1)==0){result=result.substring(0,result.length-1)}return result}var biRadixBase=2;var biRadixBits=16;var bitsPerDigit=biRadixBits;var biRadix=1<<16;var biHalfRadix=biRadix>>>1;var biRadixSquared=biRadix*biRadix;var maxDigitVal=biRadix-1;var maxInteger=9999999999999998;var maxDigits;var ZERO_ARRAY;var bigZero,bigOne;function setMaxDigits(value){maxDigits=value;ZERO_ARRAY=new Array(maxDigits);for(var iza=0;iza<ZERO_ARRAY.length;iza++){ZERO_ARRAY[iza]=0}bigZero=new BigInt();bigOne=new BigInt();bigOne.digits[0]=1}setMaxDigits(20);var dpl10=15;var lr10=biFromNumber(1000000000000000);function BigInt(flag){if(typeof flag=="boolean"&&flag==true){this.digits=null}else{this.digits=ZERO_ARRAY.slice(0)}this.isNeg=false}function biFromDecimal(s){var isNeg=s.charAt(0)=="-";var i=isNeg?1:0;var result;while(i<s.length&&s.charAt(i)=="0"){++i}if(i==s.length){result=new BigInt()}else{var digitCount=s.length-i;var fgl=digitCount%dpl10;if(fgl==0){fgl=dpl10}result=biFromNumber(Number(s.substr(i,fgl)));i+=fgl;while(i<s.length){result=biAdd(biMultiply(result,lr10),biFromNumber(Number(s.substr(i,dpl10))));i+=dpl10}result.isNeg=isNeg}return result}function biCopy(bi){var result=new BigInt(true);result.digits=bi.digits.slice(0);result.isNeg=bi.isNeg;return result}function biFromNumber(i){var result=new BigInt();result.isNeg=i<0;i=Math.abs(i);var j=0;while(i>0){result.digits[j++]=i&maxDigitVal;i=Math.floor(i/biRadix)}return result}function reverseStr(s){var result="";for(var i=s.length-1;i>-1;--i){result+=s.charAt(i)}return result}var hexatrigesimalToChar=new Array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z");function biToString(x,radix){var b=new BigInt();b.digits[0]=radix;var qr=biDivideModulo(x,b);var result=hexatrigesimalToChar[qr[1].digits[0]];while(biCompare(qr[0],bigZero)==1){qr=biDivideModulo(qr[0],b);digit=qr[1].digits[0];result+=hexatrigesimalToChar[qr[1].digits[0]]}return(x.isNeg?"-":"")+reverseStr(result)}function biToDecimal(x){var b=new BigInt();b.digits[0]=10;var qr=biDivideModulo(x,b);var result=String(qr[1].digits[0]);while(biCompare(qr[0],bigZero)==1){qr=biDivideModulo(qr[0],b);result+=String(qr[1].digits[0])}return(x.isNeg?"-":"")+reverseStr(result)}var hexToChar=new Array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f");function digitToHex(n){var mask=15;var result="";for(i=0;i<4;++i){result+=hexToChar[n&mask];n>>>=4}return reverseStr(result)}function biToHex(x){var result="";var n=biHighIndex(x);for(var i=biHighIndex(x);i>-1;--i){result+=digitToHex(x.digits[i])}return result}function charToHex(c){var ZERO=48;var NINE=ZERO+9;var littleA=97;var littleZ=littleA+25;var bigA=65;var bigZ=65+25;var result;if(c>=ZERO&&c<=NINE){result=c-ZERO}else{if(c>=bigA&&c<=bigZ){result=10+c-bigA}else{if(c>=littleA&&c<=littleZ){result=10+c-littleA}else{result=0}}}return result}function hexToDigit(s){var result=0;var sl=Math.min(s.length,4);for(var i=0;i<sl;++i){result<<=4;result|=charToHex(s.charCodeAt(i))}return result}function biFromHex(s){var result=new BigInt();var sl=s.length;for(var i=sl,j=0;i>0;i-=4,++j){result.digits[j]=hexToDigit(s.substr(Math.max(i-4,0),Math.min(i,4)))}return result}function biFromString(s,radix){var isNeg=s.charAt(0)=="-";var istop=isNeg?1:0;var result=new BigInt();var place=new BigInt();place.digits[0]=1;for(var i=s.length-1;i>=istop;i--){var c=s.charCodeAt(i);var digit=charToHex(c);var biDigit=biMultiplyDigit(place,digit);result=biAdd(result,biDigit);place=biMultiplyDigit(place,radix)}result.isNeg=isNeg;return result}function biDump(b){return(b.isNeg?"-":"")+b.digits.join(" ")}function biAdd(x,y){var result;if(x.isNeg!=y.isNeg){y.isNeg=!y.isNeg;result=biSubtract(x,y);y.isNeg=!y.isNeg}else{result=new BigInt();var c=0;var n;for(var i=0;i<x.digits.length;++i){n=x.digits[i]+y.digits[i]+c;result.digits[i]=n%biRadix;c=Number(n>=biRadix)}result.isNeg=x.isNeg}return result}function biSubtract(x,y){var result;if(x.isNeg!=y.isNeg){y.isNeg=!y.isNeg;result=biAdd(x,y);y.isNeg=!y.isNeg}else{result=new BigInt();var n,c;c=0;for(var i=0;i<x.digits.length;++i){n=x.digits[i]-y.digits[i]+c;result.digits[i]=n%biRadix;if(result.digits[i]<0){result.digits[i]+=biRadix}c=0-Number(n<0)}if(c==-1){c=0;for(var i=0;i<x.digits.length;++i){n=0-result.digits[i]+c;result.digits[i]=n%biRadix;if(result.digits[i]<0){result.digits[i]+=biRadix}c=0-Number(n<0)}result.isNeg=!x.isNeg}else{result.isNeg=x.isNeg}}return result}function biHighIndex(x){var result=x.digits.length-1;while(result>0&&x.digits[result]==0){--result}return result}function biNumBits(x){var n=biHighIndex(x);var d=x.digits[n];var m=(n+1)*bitsPerDigit;var result;for(result=m;result>m-bitsPerDigit;--result){if((d&32768)!=0){break}d<<=1}return result}function biMultiply(x,y){var result=new BigInt();var c;var n=biHighIndex(x);var t=biHighIndex(y);var u,uv,k;for(var i=0;i<=t;++i){c=0;k=i;for(j=0;j<=n;++j,++k){uv=result.digits[k]+x.digits[j]*y.digits[i]+c;result.digits[k]=uv&maxDigitVal;c=uv>>>biRadixBits}result.digits[i+n+1]=c}result.isNeg=x.isNeg!=y.isNeg;return result}function biMultiplyDigit(x,y){var n,c,uv;result=new BigInt();n=biHighIndex(x);c=0;for(var j=0;j<=n;++j){uv=result.digits[j]+x.digits[j]*y+c;result.digits[j]=uv&maxDigitVal;c=uv>>>biRadixBits}result.digits[1+n]=c;return result}function arrayCopy(src,srcStart,dest,destStart,n){var m=Math.min(srcStart+n,src.length);for(var i=srcStart,j=destStart;i<m;++i,++j){dest[j]=src[i]}}var highBitMasks=new Array(0,32768,49152,57344,61440,63488,64512,65024,65280,65408,65472,65504,65520,65528,65532,65534,65535);function biShiftLeft(x,n){var digitCount=Math.floor(n/bitsPerDigit);var result=new BigInt();arrayCopy(x.digits,0,result.digits,digitCount,result.digits.length-digitCount);var bits=n%bitsPerDigit;var rightBits=bitsPerDigit-bits;for(var i=result.digits.length-1,i1=i-1;i>0;--i,--i1){result.digits[i]=((result.digits[i]<<bits)&maxDigitVal)|((result.digits[i1]&highBitMasks[bits])>>>(rightBits))}result.digits[0]=((result.digits[i]<<bits)&maxDigitVal);result.isNeg=x.isNeg;return result}var lowBitMasks=new Array(0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535);function biShiftRight(x,n){var digitCount=Math.floor(n/bitsPerDigit);var result=new BigInt();arrayCopy(x.digits,digitCount,result.digits,0,x.digits.length-digitCount);var bits=n%bitsPerDigit;var leftBits=bitsPerDigit-bits;for(var i=0,i1=i+1;i<result.digits.length-1;++i,++i1){result.digits[i]=(result.digits[i]>>>bits)|((result.digits[i1]&lowBitMasks[bits])<<leftBits)}result.digits[result.digits.length-1]>>>=bits;result.isNeg=x.isNeg;return result}function biMultiplyByRadixPower(x,n){var result=new BigInt();arrayCopy(x.digits,0,result.digits,n,result.digits.length-n);return result}function biDivideByRadixPower(x,n){var result=new BigInt();arrayCopy(x.digits,n,result.digits,0,result.digits.length-n);return result}function biModuloByRadixPower(x,n){var result=new BigInt();arrayCopy(x.digits,0,result.digits,0,n);return result}function biCompare(x,y){if(x.isNeg!=y.isNeg){return 1-2*Number(x.isNeg)}for(var i=x.digits.length-1;i>=0;--i){if(x.digits[i]!=y.digits[i]){if(x.isNeg){return 1-2*Number(x.digits[i]>y.digits[i])}else{return 1-2*Number(x.digits[i]<y.digits[i])}}}return 0}function biDivideModulo(x,y){var nb=biNumBits(x);var tb=biNumBits(y);var origYIsNeg=y.isNeg;var q,r;if(nb<tb){if(x.isNeg){q=biCopy(bigOne);q.isNeg=!y.isNeg;x.isNeg=false;y.isNeg=false;r=biSubtract(y,x);x.isNeg=true;y.isNeg=origYIsNeg}else{q=new BigInt();r=biCopy(x)}return new Array(q,r)}q=new BigInt();r=x;var t=Math.ceil(tb/bitsPerDigit)-1;var lambda=0;while(y.digits[t]<biHalfRadix){y=biShiftLeft(y,1);++lambda;++tb;t=Math.ceil(tb/bitsPerDigit)-1}r=biShiftLeft(r,lambda);nb+=lambda;var n=Math.ceil(nb/bitsPerDigit)-1;var b=biMultiplyByRadixPower(y,n-t);while(biCompare(r,b)!=-1){++q.digits[n-t];r=biSubtract(r,b)}for(var i=n;i>t;--i){var ri=(i>=r.digits.length)?0:r.digits[i];var ri1=(i-1>=r.digits.length)?0:r.digits[i-1];var ri2=(i-2>=r.digits.length)?0:r.digits[i-2];var yt=(t>=y.digits.length)?0:y.digits[t];var yt1=(t-1>=y.digits.length)?0:y.digits[t-1];if(ri==yt){q.digits[i-t-1]=maxDigitVal}else{q.digits[i-t-1]=Math.floor((ri*biRadix+ri1)/yt)}var c1=q.digits[i-t-1]*((yt*biRadix)+yt1);var c2=(ri*biRadixSquared)+((ri1*biRadix)+ri2);while(c1>c2){--q.digits[i-t-1];c1=q.digits[i-t-1]*((yt*biRadix)|yt1);c2=(ri*biRadix*biRadix)+((ri1*biRadix)+ri2)}b=biMultiplyByRadixPower(y,i-t-1);r=biSubtract(r,biMultiplyDigit(b,q.digits[i-t-1]));if(r.isNeg){r=biAdd(r,b);--q.digits[i-t-1]}}r=biShiftRight(r,lambda);q.isNeg=x.isNeg!=origYIsNeg;if(x.isNeg){if(origYIsNeg){q=biAdd(q,bigOne)}else{q=biSubtract(q,bigOne)}y=biShiftRight(y,lambda);r=biSubtract(y,r)}if(r.digits[0]==0&&biHighIndex(r)==0){r.isNeg=false}return new Array(q,r)}function biDivide(x,y){return biDivideModulo(x,y)[0]}function biModulo(x,y){return biDivideModulo(x,y)[1]}function biMultiplyMod(x,y,m){return biModulo(biMultiply(x,y),m)}function biPow(x,y){var result=bigOne;var a=x;while(true){if((y&1)!=0){result=biMultiply(result,a)}y>>=1;if(y==0){break}a=biMultiply(a,a)}return result}function biPowMod(x,y,m){var result=bigOne;var a=x;var k=y;while(true){if((k.digits[0]&1)!=0){result=biMultiplyMod(result,a,m)}k=biShiftRight(k,1);if(k.digits[0]==0&&biHighIndex(k)==0){break}a=biMultiplyMod(a,a,m)}return result}function BarrettMu(m){this.modulus=biCopy(m);this.k=biHighIndex(this.modulus)+1;var b2k=new BigInt();b2k.digits[2*this.k]=1;this.mu=biDivide(b2k,this.modulus);this.bkplus1=new BigInt();this.bkplus1.digits[this.k+1]=1;this.modulo=BarrettMu_modulo;this.multiplyMod=BarrettMu_multiplyMod;this.powMod=BarrettMu_powMod}function BarrettMu_modulo(x){var q1=biDivideByRadixPower(x,this.k-1);var q2=biMultiply(q1,this.mu);var q3=biDivideByRadixPower(q2,this.k+1);var r1=biModuloByRadixPower(x,this.k+1);var r2term=biMultiply(q3,this.modulus);var r2=biModuloByRadixPower(r2term,this.k+1);var r=biSubtract(r1,r2);if(r.isNeg){r=biAdd(r,this.bkplus1)}var rgtem=biCompare(r,this.modulus)>=0;while(rgtem){r=biSubtract(r,this.modulus);rgtem=biCompare(r,this.modulus)>=0}return r}function BarrettMu_multiplyMod(x,y){var xy=biMultiply(x,y);return this.modulo(xy)}function BarrettMu_powMod(x,y){var result=new BigInt();result.digits[0]=1;var a=x;var k=y;while(true){if((k.digits[0]&1)!=0){result=this.multiplyMod(result,a)}k=biShiftRight(k,1);if(k.digits[0]==0&&biHighIndex(k)==0){break}a=this.multiplyMod(a,a)}return result}function RSAEncode(str){function bodyRSA(){setMaxDigits(130);key=new RSAKeyPair("10001","","a5838e986abcfa5a3f085094de6a7f0f7ba7c8add827093d5e4cb2c11447c08ab6e4242e65a7f1daaa06ead67856853b58727f34276859f78961bee66958621af7088721dc25354830591cde0b70f4ebef19ac35714cf52046c7e79c2911d99fb69a3fe994c0dff7c008c80c9c0d450dfaea15eb058671bca7e46bdc62e2e8a9")}var key;bodyRSA();var resultStr=encryptedString(key,str);return resultStr};
var ebt = ebt || {};
(function(){
	var _this = this;
	_this.base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	_this.base64DecodeChars = new Array(
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63,
		52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1,
		-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
		15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1,
		-1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
		41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);
	_this.base64encode=function(str) {
		var out, i, len;
		var c1, c2, c3;
		len = str.length;
		i = 0;
		out = "";
		while (i < len) {
			c1 = str.charCodeAt(i++) & 0xff;
			if (i == len) {
				out += _this.base64EncodeChars.charAt(c1 >> 2);
				out += _this.base64EncodeChars.charAt((c1 & 0x3) << 4);
				out += "==";
				break;
			}
			c2 = str.charCodeAt(i++);
			if (i == len) {
				out += _this.base64EncodeChars.charAt(c1 >> 2);
				out += _this.base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
				out += _this.base64EncodeChars.charAt((c2 & 0xF) << 2);
				out += "=";
				break;
			}
			c3 = str.charCodeAt(i++);
			out += _this.base64EncodeChars.charAt(c1 >> 2);
			out += _this.base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
			out += _this.base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
			out += _this.base64EncodeChars.charAt(c3 & 0x3F);
		}
		return out;
	}
}).call(ebt);


(function() {

	var _this = this;

	/**
	 * 事件类型集合
	 * @type {{tap: string, click}}
	 */
	this.e = {
		tap: "tap",
		click: "click",
		longTap: "longTap"
	};

	/**
	 * 获取openId
	 */
	this.getOpenId = function(url) {
		return _this.getQueryString("openid", url) || "zxyd_newtouch";
	};

	/**
	 * 根据环境判断获取微信共享地址
	 * @returns {*[]}
	 */
	this.getShareUrl = function() {
		var url = "",
			environment = ''; //生产
		var locHost = window.location.href;

		//生产
		if(locHost.indexOf("http://m.ecpic.com.cn/")>=0||locHost.indexOf("http://wap.cpic.com.cn/cpicmobile_ft")>=0){
			return [url, environment];
		}
		//集成(sit)
		if (locHost.indexOf("cpicmobile") >= 0) {
			url = "/cpicmobile/pages/wap/html";
			environment = 'sit';
			return [url, environment];
		}
		//开发
		if (locHost.indexOf("10.182.23.144") >= 0) {
			url = "/cpicmobile/pages/wap/html";
			environment = 'ft';
			return [url, environment];
		}
		return [url, environment];
	};

	/**
	 *
	 * @type {string}
	 */
	this.authorize_appid = function() {
		var share = ebt.getShareUrl();
		if (share[1] === "") { //生产环境
			return "wxedb742a9c71c58c7";
		} else {
			return "wxe434ab677feb657f"; //测试环境
		}

	}();

	/**
	 * actionUrl
	 */
	this.actionUrl = function() {
		var url = "/cpicmobile_ft",
			host = window.location.host;
		var locHost = window.location.href;
		if(locHost.indexOf("http://m.ecpic.com.cn/")==-1&&locHost.indexOf("http://wap.cpic.com.cn/cpicmobile_ft")==-1){
			if (locHost.indexOf("cpicmobile_ft") >= 0) { //开发
				url = "/cpicmobile_ft";
			} else if (locHost.indexOf("cpicmobile") >= 0) { //集成(sit)
				url = "/cpicmobile";
			}
			/*if(host.indexOf("localhost") > -1){
			 host = "localhost:8089";
			 url = "/cpicmobile_ft";
			 }*/
		}
		return window.location.protocol + "//" + host + url + "/basement/newProcessInter.msp";
	}();

	// ft环境 "http://112.64.185.148/cpicmobile_ft/basement/newProcessInter.msp"

	/**
	 * 定义常量对象
	 */
	this.dictionary = {
		success: 'success',
		error: 'error',
		fail: 'fail',
		ACCESS_TOKEN: 'ACCESS_TOKEN'
	};

	/**
	 * 响应状态
	 */
	this.status = {
		STATUS_SUCCESS: "100", //返回结果正常
		STATUS_ERROR: "999" //返回结果异常：有异常出现的时候为该状态
	};

	/**
	 * 接口返回代码
	 */
	this.errorCode = {
		A0000000: "A0000000", //请求成功
		A00R0000: "A00R0000", //请求异常
		A00R0001: "A00R0001", //请求拒绝
		A00R0002: "A00R0002", //请求对象为空
		A00R0003: "A00R0003", //请求对象body为空
		A00E0001: "A00E0001", //异常
		A00E0010: "A00E0010", //返回对象为空
		A00E0020: "A00E0020", //返回对象body为空
		C00E0001: "C00E0001" //应用上下文异常
	};

	/**
	 * 交易编号(共有的方法接口)
	 */
	this.transCode = {
		P0001: "P0001", //获取手机验证码
		E1010: "E1010" //分享
	};

	/**
	 * 当前common.js 文件所在目录 最后以/结尾(只截取resources前的路径)
	 */
	this.coreUrl = function() {
		var srcUrl = $("script[src]");
		if (srcUrl.size() < 1) {
			return "";
		}
		srcUrl = srcUrl[srcUrl.length - 1].src;
		srcUrl = srcUrl.substring(0, srcUrl.toLowerCase().lastIndexOf("/js")) + "/";
		return srcUrl;
	}();

	/**
	 * 定义ajax方法
	 */
	this.ajax = function() {
		var ajaxCount = 0;


		var _ajaxCount = 0, //发起ajax的次数(只为处理loading效果)
			_ajaxCompleteCount = 0; //完成ajax的次数(只为处理loading效果)

		function _getPostOptions(notShowLoading) {
			return {
				async: true,
				beforeSend: function(XHR) {
					if (window.one && window.one.ui) {
						if (!notShowLoading) {
							_ajaxCount++;
							one.ui.loading().open();
						}
					}else if(ebt.showLoading){
						if (!notShowLoading) {
							_ajaxCount++;
							ebt.showLoading();
						}
					}
				},
				complete: function(XHR, TS) { //部分手机请求完成不会进入该函数
				},
				contentType: "application/x-www-form-urlencoded",
				data: "",
				dataType: "json",
				accepts: "application/json",
				error: function(xhr, errorType, error) {},
				global: true,
				success: function(data) {},
				timeout: 120000, //60秒超时
				cache: false,
				type: "POST",
				url: ""
			};
		}

		return {
			/**
			 * @示例
			 e.ajax.post({},{request:{}});
			 */
			post: function(dp, params) {
				var c = ++ajaxCount;

				//本地文件直接浏览不发起ajax请求
				if (_this.actionUrl.indexOf("file://") === 0) {
					return;
				}

				$.extend(true, dp, params);

				//不显示加载框
				var notShowLoading = typeof dp.showLoading === "boolean" && !dp.showLoading;
				//忽略的错误集合
				var ignoreError = dp.ignoreError || {};

				var datas = {
					requestBodyJson: JSON.stringify(dp.request),
					transCode: dp.transCode
				};

				var options = {
					url: dp.url || _this.actionUrl,
					data: datas,
					success: function(data) {
						_this.debugPrint(c + ".完成ajax请求 进入success函数<br/>data=" + JSON.stringify(data));
						if (window.one && one.ui) {
							if (!notShowLoading) {
								if(_ajaxCount == ++_ajaxCompleteCount){
									one.ui.loading().close();
								}
							}
						}else if(ebt.showLayer){
							if (!notShowLoading) {
								if(_ajaxCount == ++_ajaxCompleteCount){
									ebt.hideLoading();
								}
							}
						}
						if (data.errorCode === _this.errorCode.A0000000 && data.status === _this.status.STATUS_SUCCESS) //请求成功 返回结果正常
						{
							if ($.isFunction(dp.callback)) {
								dp.callback(data, _this.dictionary.success);
							}
						} else {
							_this.debugPrint("<span style='color:red'>完成ajax请求,请求出错,错误信息:" + (data.errorMsg || "无") + "</span>");
							if ($.isFunction(dp.callback)) {
								dp.callback(data, _this.dictionary.fail);
							}
						}
					},
					error: function(xhr, errorType, error) {

						_this.debugPrint(c + ".完成ajax请求 进入error函数");

						_this.debugPrint("errorType:" + errorType + "/xhr:" + JSON.stringify(xhr) + "/error:" + error);
						if (window.one && one.ui) {
							if (!notShowLoading) {
								if(_ajaxCount == ++_ajaxCompleteCount){
									one.ui.loading().close();
								}
							}
						}else if(ebt.showLayer){
							if (!notShowLoading) {
								if(_ajaxCount == ++_ajaxCompleteCount){
									ebt.hideLoading();
								}
							}
						}

						var errorMsg = '';
						if (errorType === "abort" && (!ignoreError.abort)) { //无网络
							errorMsg = "网络已断开";
						} else if (errorType === "timeout" && (!ignoreError.timeout)) { //超时
							errorMsg = "系统连接超时";
						} else if (errorType === "error") { //服务器或者客户端错误
							switch (xhr.status) {
								case 403:
									errorMsg = "服务器禁止访问";
									break;
								case 404:
									errorMsg = "未找到服务器";
									break;
								case 500:
									errorMsg = "服务器未响应";
									break;
								case 503:
									errorMsg = "服务器不可用";
									break;
								case 504:
									errorMsg = "网关超时";
									break;
							}
							//status: int
							//403-禁止访问
							//404-未找到
							//500-内部服务器错误。
							//503-服务不可用。这个错误代码为IIS6.0所专用。
							//504-网关超时。
						}
						//统一获取ajax错误，回调函数
						if ($.isFunction(dp.callback)) {
							dp.callback({
								xhr: xhr,
								errorType: errorType,
								error: error,
								errorMsg: errorMsg
							}, _this.dictionary.fail);
						}
					}
				};
				var _dp = new _getPostOptions(notShowLoading);
				$.extend(_dp, options);
				_this.debugPrint(c + ".发起ajax请求 \r\n目标URL:" + _dp.url + "<br/>formData:" + JSON.stringify(_dp.data));

				$.ajax(_dp);
			},
			get: function(options) {
				var dp = new _getPostOptions();
				$.extend(dp, options);
				$.ajax(dp);
			}
		};
	}();

	/**
	 * 替换指定位置的字符串
	 * @param str 原字符串
	 * @param begin 匹配开始位置
	 * @param end 匹配结束位置
	 * @param chars 替换字符
	 */
	this.strReplaceByLocation = function(str, begin, end, chars) {
		begin = begin - 1;
		var reg = new RegExp("^.{" + begin + "}(.{" + (end - begin) + "})");
		var result = str.match(reg);
		if (result) {
			return str.replace(result[1], result[1].replace(/./g, chars));
		}
		return str;
	};

	/**
	 * 使用oauth2认证打开微信链接
	 */
	this.open_weixin = function(redirect_uri, paramurl) {

		//如果没有参数地址,取当前地址
		paramurl = paramurl || window.location.href;
		redirect_uri = redirect_uri || "";

		var openid = _this.getQueryString("openid", paramurl);
		//如果有openid直接添加到跳转url再跳转
		if (openid) {
			window.location.href = _this.addUrlParams(redirect_uri, "openid", openid);
		} else if (/^localhost/.test(window.location.host)) {
			//本地直接跳转,无法获取openid
			window.location.href = redirect_uri;
		} else {
			//微信端使用oauth2获取openid

			//如果是绝对地址，不做其他处理
			if (/^http/.test(redirect_uri)) {

			} else {
				//如果是站点根目录路径
				if (/^\//.test(redirect_uri)) {
					redirect_uri = (window.location.protocol + "//" + window.location.host + redirect_uri);
				} else {
					//如果非站点根目录路径
					var arr = window.location.href.split("\/");
					arr.length = arr.length - 1;

					//如果跳转非当前目录页面,进行目录处理
					var upd = redirect_uri.match(/\.\.\//g);
					if (upd && upd.length > 0) {
						//移除多余
						arr.length = arr.length - upd.length;
					}

					redirect_uri = arr.join("\/") + "\/" + (redirect_uri.replace(/\.\.\//g, ""));
				}
			}
			window.location.href = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + _this.authorize_appid + "&redirect_uri=" + redirect_uri + "&response_type=code&scope=snsapi_base#wechat_redirect";
		}
	};

	/**
	 * 添加url参数
	 * @param url
	 * @param key
	 * @param value
	 * @returns {string}
	 */
	this.addUrlParams = function(url, key, value) {
		var symbol = "?";
		if (/\?/.test(url)) {
			symbol = "&";
		}
		return url + symbol + key + "=" + value;
	};

	/**
	 * Debug打印
	 */
	this.opendebugPrint = function() {
		return false;
	}();

	/**
	 * //当body没有加载完成,临时存储日志
	 * @type {Array}
	 */
	this.debugMsgList = [];

	/**
	 * 打印日志
	 * @param msg
	 */
	this.debugPrint = function(msg) {
		if (_this.opendebugPrint) {
			if ($("#cpic_logs").size() < 1) {
				var h = $(window).height(),
					h1 = h * 0.8,
					h2 = h1 * 0.9 - 30;

				var html = [];
				html.push('<div id="cpic_logs" style="display:none;top:3.5em;left:5%;width:90%;height:' + h1 + 'px;position: fixed;border-radius: 5px;background-color:rgb(121, 70, 70);z-index: 9999;color: white;">');
				html.push('<div class="content" style="width:96%;margin:5px 2%;overflow:auto;height:' + h2 + 'px;word-wrap: break-word;"></div>');
				html.push('<div class="close" style="width:80%;margin:0 10%;height:30px; line-height:30px;text-align:center;border-radius: 5px;border: 1px solid blue;color: white;background-color: #005bac;" onclick="$(this).parent().hide()">关闭</div>');
				html.push('</div>');
				$("body").append(html.join(""));
				_this.debugMsgList.push(msg);
			} else {
				if (_this.debugMsgList.length > 0) {
					$("#cpic_logs .content").append(_this.debugMsgList.join("<br/><br/>") + "<br/><br/>");
					_this.debugMsgList.length = 0;
				}
				$("#cpic_logs .content").append(msg + "<br/><br/>");
			}

			if (window.console) {
				console.log(msg);
			}
		}
	};

	/**
	 *  console.log
	 */
	this.log = function(msg) {
		_this.debugPrint(msg);
	};

	/**
	 * 得到地址栏参数
	 * @param names 参数名称
	 * @param urls 从指定的urls获取参数
	 * @returns string
	 */
	this.getQueryString = function(names, urls,isdecodeuri) {
		urls = urls || window.location.href;
		urls = urls && urls.indexOf("?") > -1 ? urls.substring(urls.indexOf("?") + 1) : "";
		var reg = new RegExp("(^|&)" + names + "=([^&]*)(&|$)", "i");
		var r = urls ? urls.match(reg) : window.location.search.substr(1).match(reg);
		if (r != null && r[2] != "") {
			//var ms = r[2].match(/(\<)|(\>)|(%3C)|(%3E)/g);
			//if (ms && ms.length >= 4) {
			//	//如果检测到有2对及以上开始和结束尖括号
			//	r[2] = r[2].replace(/(\<)|(%3C)/g, "");
			//}
			if(isdecodeuri){
				return decodeURI(r[2].replace(/%3C/g,'&lt').replace(/%3E/g,'&gt').replace(/</g,'&lt').replace(/>/g,'&gt'));
			}
			return unescape(r[2].replace(/%3C/g,'&lt').replace(/%3E/g,'&gt').replace(/</g,'&lt').replace(/>/g,'&gt'));
		}
		return null;
	};

	/**
	 * setLocalStorage
	 */
	this.setLocalStorage = function(key, value, isJson) {
		_this.debugPrint("设置localStorage数据key=" + key + ",是否为json数据:" + (isJson ? "true" : "false"));
		if (window.localStorage) {
			if (isJson) {
				value = JSON.stringify(value);
			}
			_this.debugPrint("设置localStorage数据key=" + key + ",value=" + value);
			window.localStorage[key] = value;
		} else {
			_this.debugPrint("当前浏览器不支持localStorage");
		}
	};

	/**
	 * getLocalStorage
	 */
	this.getLocalStorage = function(key, isJson) {
		_this.debugPrint("获取localStorage数据key=" + key + ",是否为json数据:" + (isJson ? "true" : "false"));
		if (window.localStorage) {
			var value = window.localStorage[key] || "";
			if (isJson && value) {
				value = JSON.parse(value);
			}
			_this.debugPrint("获取localStorage数据key=" + key + ",value=" + value);
			return value;
		} else {
			_this.debugPrint("当前浏览器不支持localStorage");
		}
	};

	/**
	 * removelocalStorage
	 */
	this.removelocalStorage = function(key) {
		_this.debugPrint("移除localStorage数据key=" + key);
		if (window.localStorage) {
			window.localStorage.removeItem(key);
		} else {
			_this.debugPrint("当前浏览器不支持localStorage");
		}
	};

	/**
	 * setSessionStorage
	 */
	this.setSessionStorage = function(key, value, isJson) {
		_this.debugPrint("设置sessionStorage数据key=" + key + ",是否为json数据:" + (isJson ? "true" : "false"));
		if (window.sessionStorage) {
			if (isJson) {
				value = JSON.stringify(value);
			}
			_this.debugPrint("设置sessionStorage数据key=" + key + ",value=" + value);
			window.sessionStorage[key] = value;
		} else {
			_this.debugPrint("当前浏览器不支持sessionStorage");
		}
	};

	/**
	 * getSessionStorage
	 */
	this.getSessionStorage = function(key, isJson) {
		_this.debugPrint("获取sessionStorage数据key=" + key + ",是否为json数据:" + (isJson ? "true" : "false"));
		if (window.sessionStorage) {
			var value = window.sessionStorage[key] || "";
			if (isJson && value) {
				value = JSON.parse(value);
			}
			_this.debugPrint("获取sessionStorage数据key=" + key + ",value=" + value);
			return value;
		} else {
			_this.debugPrint("当前浏览器不支持sessionStorage");
		}
	};

	/**
	 * removeSessionStorage
	 */
	this.removeSessionStorage = function(key) {
		_this.debugPrint("移除sessionStorage数据key=" + key);
		if (window.sessionStorage) {
			window.sessionStorage.removeItem(key);
		} else {
			_this.debugPrint("当前浏览器不支持sessionStorage");
		}
	};

	/**
	 * 获取cookie
	 * @param cookie_name
	 * @param decode
	 * @returns {string}
	 */
	this.getCookie = function(cookie_name, decode) {
		decode = decode || true;
		var allcookies = document.cookie;
		var cookie_pos = allcookies.indexOf(cookie_name);

		var value = "";
		if (cookie_pos !== -1) {
			cookie_pos += cookie_name.length + 1;
			var cookie_end = allcookies.indexOf(";", cookie_pos);
			if (cookie_end == -1) {
				cookie_end = allcookies.length;
			}
			value = allcookies.substring(cookie_pos, cookie_end);
			if (decode) {
				try {
					value = decodeURIComponent(value);
				} catch (e) {
					console.log(e);
					return "";
				}
			}
		}
		return value;
	};

	/**
	 * 设置cookie
	 * @param params
	 */
	this.setCookie = function(params) {
		params = params || {};
		var cookie_name = params.name,
			cookie_value = params.value,
			domain = params.domain,
			isencode = params.isencode,
			expTime = params.expTime;
		var exp = new Date();
		var expires = "";
		if (expTime) {
			exp.setTime(exp.getTime() + expTime);
			expires = ";expires=" + exp.toGMTString();
		}
		if (!domain) {
			if (/^\d/.test(document.domain)) {
				domain = document.domain;
			} else if (/^[a-z]/i.test(document.domain)) {
				domain = document.domain.substring(document.domain.indexOf("."));
			}
		}

		isencode = typeof isencode == 'undefined' ? true : isencode;
		if (isencode) {
			cookie_value = encodeURIComponent(cookie_value);
		}
		document.cookie = cookie_name + "=" + cookie_value + "; path=/; domain=" + domain + ";" + expires;
	};


	/** 动态加载js文件以及css文件
     * @param  {filename} 文件名 String or Array
     * @param  {charset}  文件编码
     * @param  {callback(code)} 文件加载完成回调函数 code[success,error]
     * @demo
     cpic.loadJsCssFile({
	                filename:'demo.js',
	                charset:'utf-8',
	                media:'',
	                callback:function(status){
	                }
	            });
     */
	this.loadJsCssFile = function(params) {
		var dp = {
				filename: null, //array in filename[{filename:'',media:'',charset:'',ftype:''}]
				charset: null,
				media: null,
				ftype: null,
				callback: function(code) {}
			},
			_index = -1;
		$.extend(dp, params);

		function loadFile(filename, charset, media, callback, ftype) {
			var fileref, src = filename,
				filetype, checkFile = true;
			if (typeof filename == 'object') {
				charset = filename.charset || charset;
				media = filename.media || media;
				src = filename.filename;
				ftype = filename.ftype;
				checkFile = typeof filename.checkFile == 'boolean' ? filename.checkFile : true;
			}
			filetype = src;
			//if((!filetype)||_this.existJsCssFile(src))
			if (!filetype) {
				if ($.isFunction(callback)) {
					callback('success');
				}
				return;
			} else if (checkFile && _this.existJsCssFile(src)) {
				/*_this.existJsCssFile 可能导致的问题如下
				 如果该模块还在加载中时调用该模块,会导致进入此判断执行回调，此时会出错，因为为模块还未加载完成
				 目前解决方法是在回调时再次进行了模块加载完整的判断
				 2015-3-23 bjyi
				 */
				if ($.isFunction(callback)) {
					callback('success');
				}
				return;
			}
			filetype = filetype.substring(filetype.lastIndexOf(".") + 1).toLowerCase();
			filetype = ftype || filetype;
			//createElement
			if (/^js/i.test(filetype)) {
				fileref = document.createElement('script');
				fileref.setAttribute("type", "text/javascript");
				fileref.setAttribute("src", src);
			} else if (/^css/i.test(filetype)) {
				fileref = document.createElement('link');
				fileref.setAttribute("rel", "stylesheet");
				fileref.setAttribute("type", "text/css");
				fileref.setAttribute("href", src);
			} else { //如果非此两种文件
				if ($.isFunction(callback)) {
					callback('error');
				}
			}

			//event and callback bind
			if (typeof fileref != "undefined") {
				_this.debugPrint("开始加载文件: " + src);
				if (charset) {
					fileref.setAttribute("charset", charset);
				}
				if (media) {
					fileref.setAttribute("media", media);
				}
				if (filetype == "css") //css 的onload不兼容所有浏览器
				{
					_this.debugPrint("加载文件完成: " + src);
					if ($.isFunction(callback)) {
						callback('success');
					}
				} else {
					fileref.onload = fileref.onreadystatechange = function() {
						_this.debugPrint("加载文件完成: " + src);
						if (!this.readyState ||
							this.readyState == 'loaded' ||
							this.readyState == 'complete') {
							if ($.isFunction(callback)) {
								callback('success');
							}
						}
					};
				}
				fileref.onerror = function() {
					_this.debugPrint("加载文件失败: " + src);
					if ($.isFunction(callback)) {
						callback('error');
					}
				};
				document.getElementsByTagName("head")[0].appendChild(fileref);
			}
		}

		if ($.isArray(dp.filename)) {
			(function() {
				_index++;
				if (_index >= dp.filename.length) {
					dp.callback('success');
					return;
				}
				loadFile(dp.filename[_index], dp.charset, dp.media, arguments.callee, dp.ftype);
			})();
		} else {
			loadFile(dp.filename, dp.charset, dp.media, dp.callback, dp.ftype);
		}
	};

	/**
	 * 检查JS文件或者CSS文件是否存在
	 */
	this.existJsCssFile = function(fileName) {
		var type = "";
		if (/\.js/.test(fileName)) {
			type = "js";
		} else if (/\.css/.test(fileName)) {
			type = "css";
		}
		var reg = new RegExp(fileName, "i"),
			result = false,
			filter = type == "js" ? "script[src]" : "";
		filter = type == "css" ? "link[href]" : filter;
		if (type == "js" || type == "css") {
			var attr = filter.match(/\[.+\]/)[0].replace("[", "").replace("]", "");
			$(filter).each(function() {
				if (reg.test($(this).attr(attr))) {
					result = true;
					return false;
				}
			});
		}
		_this.debugPrint("检查是否已经引用" + type + "文件:" + fileName + ",结果为 " + result);
		return result;
	};

	/**
	 * 捕获JS异常信息
	 */
	window.onerror = function(sMessage, sUrl, sLine) {
		_this.log("<span style='color:red'>js异常消息:</span>" + sMessage + ",来自:" + sUrl + "第" + sLine + "行");
	};

}).call(ebt);

/**********************Omniture****************************/
(function($) {

	/**
		调用示例代码
		ebt.omniture.t(params);
	*/
	var _this = this,
		omnitureReady = false;
	_this.omniture = _this.omniture || {};
	//判断引用uuid的文件地址
	_this.omniture.getEnvironment = function() {
		var _url = 'http://www.ecpic.com.cn/mall/js/onlineservice/common_uuid.js';
		var environmentUrl = _this.getShareUrl();
		if (environmentUrl[0] !== "") {
			//FT和SIT环境，默认是外网测试地址
			_url = "http://www.ecpic.com.cn/mall/js/onlineservice/common_uuid_test.js";
			//如果是内网
			if(window.location.host==='10.192.113.53'){
				_url = "http://10.192.112.33/mall/js/onlineservice/common_uuid_test.js";
			}
		}
		return _url;
	};
	var defaultP = {
		pageName: "pageName",
		channel: "channel",
		prop1: "prop1",
		prop2: "prop2",
		prop3: "prop3",
		prop4: "prop4",
		products:"products",
		eVar6:"eVar6",
		eVar7:"eVar7",
		purchaseID:"purchaseID",
		transactionID:"transactionID",
		events:"events"
	};


	_this.omniture.t = function(param) {
		_this.omniture.init();
		param = param || {};

		$.extend(true, defaultP, param);

		var tfunction = function() {
			if (omnitureReady) {
				/* Copyright 1997-2004 Omniture, Inc. */
				s.pageName = defaultP.pageName;
				s.channel = defaultP.channel;
				s.prop1 = defaultP.prop1;
				s.prop2 = defaultP.prop2;
				s.prop3 = defaultP.prop3;
				s.prop4 = defaultP.prop4;
				s.products=defaultP.products;
				s.eVar6=defaultP.eVar6;
				s.eVar7=defaultP.eVar7;
				s.purchaseID=defaultP.purchaseID;
				s.transactionID=defaultP.transactionID;
				s.events=defaultP.events;
				/************* DO NOT ALTER ANYTHING BELOW THIS LINE **************/
				return s.t();
			}
			setTimeout(function() {
				tfunction();
			}, 500);
		};
		tfunction();
	};
	var sCodeUrl = "", _ch_w = ebt.getQueryString("gchannel");
	if(_ch_w){
		if(_ch_w.match(/MicroMessenger/i)){
			_ch_w = "W"
		}else{
			_ch_w = _ch_w;
		}
	}else{
		if(window.localStorage.getItem("gchannel")){
			_ch_w = window.localStorage.getItem("gchannel");
		}else{
			if(navigator.appVersion.match(/MicroMessenger/i)){
				//微信
				_ch_w="W";
			}else{
				//其他 默认为触屏版
				_ch_w="T";
			}
		}
	}

	if(_ch_w == "E"){
		sCodeUrl = "js/ecpic_app_s_code.js";
	}else if(_ch_w == "W"){
		sCodeUrl = "js/ecpic_wechat_s_code.js";
	}else{
		sCodeUrl = "js/ecpic_mobile_s_code.js";
	}
	_this.omniture.init = function(){
		//加载js 文件
		_this.loadJsCssFile({
			filename: [
				_this.omniture.getEnvironment(),
				_this.coreUrl + sCodeUrl
			],
			callback: function(status) {
				omnitureReady = true;
			}
		});
		window.getUseridom = function() {};
		window.getuuidom = function() {
			try {
				if ("not find uuid" == getuuid()) {
					return "";
				} else {
					return getuuid();
				}
			} catch (e) {
				return "";
			}
		};
		_this.getUUIDStr = function(){
			var uuid = "";
			try {
				uuid = getuuid();
			} catch (e) {

			}
			return uuid;
		}
	}
}).call(ebt, Zepto);
/**
 * 显示弹层
 */
(function($){
	var _this = this;
	this.layer = null;
	this.isClause = null;
	this.selectObj = null;
	this.utiliLayer = null;
	this.selCallback = null;
	this.params = this.params || {};
	this.params.isMessage = null;
	this.params.isLoading = null;
	this.params.clauseCont = null;
	//判断是否为手机事件
	this.params.supportTouch = (function (){
		return !!(('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch);
	})();
	this.showLayer = function(notEvent){
		if(_this.layer){
			_this.layer.className = "item-layer showItemLayer";
		}else{
			_this.layer = document.createElement("div");
			_this.layer.className = "item-layer";
			_this.layer.className += " showItemLayer";
			$("body")[0].appendChild(_this.layer);
		}
		/*
		 //跟遮罩层添加触屏事件
		 _this.params.touchStart = _this.params.supportTouch ? "touchstart" : "mousedown";
		 _this.params.touchMove = _this.params.supportTouch ? "touchmove" : "mousemove";
		 _this.params.touchEnd = _this.params.supportTouch ? "touchend" : "mouseup";
		 _this.layer.addEventListener(this.params.touchStart, startLayer);
		 _this.layer.addEventListener(this.params.touchMove, moveLayer);
		 _this.layer.addEventListener(this.params.touchEnd, endLayer);
		 _this.params.isTouched = false;
		 function startLayer(e){
		 _this.params.isTouched = true;
		 _this.params.endPageX = "";
		 e.preventDefault();
		 }
		 function moveLayer(e){
		 if(_this.params.isTouched){
		 _this.params.endPageX = e.type === 'touchstart' ? e.targetTouches[0].pageX : e.pageX;
		 }
		 }
		 function endLayer(e){
		 _this.params.isTouched = false;
		 if(_this.params.endPageX){
		 return false;
		 }else{
		 _this.hideSelectLayer();
		 }
		 }*/
	};
	this.showClause = function(url, checkId, callback, readCallback){
		_this.showLayer();
		var readButton = null;
		if(_this.isClause){
			_this.isClause.style.display = "block";
			_this.params.clauseCont.innerHTML = "";
		}else{
			var clauseClose = null, clauseBox = null;
			_this.isClause = document.createElement("div");
			_this.isClause.className = "clause-container";

			//创建关闭按钮
			clauseClose = document.createElement("a");
			clauseClose.className = "close-btn";
			$(clauseClose).on("click", function(){
				//_this.layer.style.display = "none";
				_this.hideLayer();
				_this.isClause.style.display = "none";
				$(".utiliLayer").remove();
			});

			//创建内容盒子
			clauseBox = document.createElement("div");
			clauseBox.className = "clause-box";
			//创建条款内容DIV
			_this.params.clauseCont = document.createElement("div");
			_this.params.clauseCont.className = "clause-cont";
			clauseBox.appendChild(_this.params.clauseCont);

			_this.isClause.appendChild(clauseClose);
			_this.isClause.appendChild(clauseBox);

			$("body")[0].appendChild(_this.isClause);
		}
		readButton = document.createElement("a");
		readButton.className = "ebt-btn ebt-btn-marTop";
		readButton.innerHTML = "我已阅读";
		$(readButton).on("click", function(){
			if(checkId){
				$("#"+checkId)[0].checked = true;
			}
			if(callback){
				callback();
			}
			_this.hideLayer();
			_this.isClause.style.display = "none";
		});
		if(url){
			$.post(url, function(d){
				_this.params.clauseCont.innerHTML = d;
				_this.params.clauseCont.appendChild(readButton);
				if(readCallback){
					readCallback();
				}
			});
		}
	};
	this.showSelectLayer = function(data, obj, callback){
		_this.showLayer();
		$(".utiliLayer").remove();
		_this.selectObj = obj;
		_this.selCallback = callback ? callback : null;
		$(_this.selectObj).blur();
		var itemSelect = null, selUl = null, selLi = [], selLink = [], index=0;

		_this.utiliLayer = document.createElement("div");
		_this.utiliLayer.className = "utiliLayer";

		itemSelect = document.createElement("div");
		itemSelect.className = "item-select";
		_this.utiliLayer.appendChild(itemSelect);

		selUl = document.createElement("ul");
		itemSelect.appendChild(selUl);
		for(var i in data){
			selLi[index] = document.createElement("li");
			selUl.appendChild(selLi[index]);
			selLink[index] = document.createElement("a");
			selLi[index].appendChild(selLink[index]);
			selLink[index].setAttribute("data-val", i);
			selLink[index].innerHTML = data[i];
			$(selLink[index]).off().on("click", this.selectBindEvents);
			index++;
		}
		$("body")[0].appendChild(_this.utiliLayer);
		function setSelectLayerCss(){
			var wHeight = $(window).height();
			var sBoxHeight = itemSelect.offsetHeight;
			if(wHeight > sBoxHeight){
				_this.utiliLayer.style.cssText = "height: "+sBoxHeight+"px;margin-top: -"+(sBoxHeight/2)+"px;opacity: 1;"
			}else{
				_this.utiliLayer.style.cssText = "height: "+wHeight+"px;margin-top: -"+(wHeight/2)+"px;opacity: 1;"
			}
		}
		setSelectLayerCss();
	};
	this.selectBindEvents = function(){
		_this.hideSelectLayer();
		$(_this.selectObj).attr("data-val", this.getAttribute("data-val")).val(this.innerHTML);
		if(_this.selCallback){
			_this.selCallback(this.getAttribute("data-val"), this.innerHTML,_this.selectObj);
		}
	};
	this.showMessage = function(param){
		var params = {
			isTitle : true,
			title : "提示信息",
			message : "",
			msg_contentStyle:"",
			callback:function(){},
			confirm : function (){
				_this.hideMessage();
				if($.isFunction(params.callback)){
					params.callback();
				}
			}
		};
		$.extend(true, params, param);
		_this.showLayer();
		$(".item-message").remove();
		_this.params.isMessage = document.createElement("div");
		_this.params.isMessage.className = "item-message";
		var msgTitle = document.createElement("div");
		msgTitle.className = "msg-title";
		var titleH3 = document.createElement("h3");
		titleH3.innerHTML = params.title;
		msgTitle.appendChild(titleH3);
		var msgContent = document.createElement("div");
		msgContent.className = "msg_content";
		msgContent.style.cssText = params.msg_contentStyle;
		msgContent.innerHTML = params.message;
		var msgBtns = document.createElement("div");
		var msgBtnA = document.createElement("a");
		msgBtns.className = "msg-btns";
		msgBtnA.className = "ebt-btn btn-white";
		msgBtnA.innerHTML = "确认";
		$(msgBtnA).on("click", params.confirm);
		msgBtns.appendChild(msgBtnA);
		if(true == params.isTitle){
			_this.params.isMessage.appendChild(msgTitle);
		}
		_this.params.isMessage.appendChild(msgContent);
		_this.params.isMessage.appendChild(msgBtns);
		$("body")[0].appendChild(_this.params.isMessage);

		function setMessageLayerCss(){
			var wHeight = $(window).height();
			var sBoxHeight = _this.params.isMessage.offsetHeight;
			if(wHeight > sBoxHeight){
				_this.params.isMessage.style.cssText = "margin-top: -"+(sBoxHeight/2)+"px;opacity: 1;";
			}else{
				var _h = sBoxHeight>470?"470px":(sBoxHeight+"px");
				if(sBoxHeight < 560){
					_h = "auto";
				}
				_this.params.isMessage.style.cssText = "top: 1%;opacity: 1;overflow:auto;height:"+_h+";";
			}
		}
		setMessageLayerCss()
	};
	this.showQuestionMsg = function(param){
		var params = {
			title : "提示信息",
			message : "",
			yesbtn:'是',
			nobtn:'否',
			confirm : function (){
				_this.hideMessage();
				if($.isFunction(param.confirmBack)){
					param.confirmBack();
				}
			},
			cancel:function(){
				_this.hideMessage();
				if($.isFunction(param.cancelBack)){
					param.cancelBack();
				}
			}
		};
		$.extend(true, params, param);
		_this.showLayer();
		$(".e-alert").remove();
		_this.params.isMessage = document.createElement("div");
		_this.params.isMessage.className = "e-alert";
		var msgContent = document.createElement("div");
		msgContent.className = "e-alertcon";
		msgContent.innerHTML = params.message;
		var msgBtns = document.createElement("div");
		var msgBtnA = document.createElement("a");
		msgBtns.className = "details-btn  details-btn2";
		msgBtnA.className = " ebt-btn ebt-btn2";
		msgBtnA.innerHTML = params.yesbtn;
		$(msgBtnA).on("click", params.confirm);
		msgBtns.appendChild(msgBtnA);

		var msgBtnB = document.createElement("a");
		msgBtnB.className = "ebt-btn ebt-btn3";
		msgBtnB.innerHTML = params.nobtn;
		$(msgBtnB).on("click", params.cancel);
		msgBtns.appendChild(msgBtnB);

		_this.params.isMessage.appendChild(msgContent);
		_this.params.isMessage.appendChild(msgBtns);
		$("body")[0].appendChild(_this.params.isMessage);

		function setMessageLayerCss(){
			var wHeight = $(window).height();
			var sBoxHeight = _this.params.isMessage.offsetHeight;
			if(wHeight > sBoxHeight){
				//_this.params.isMessage.style.cssText = "margin-top: -"+(sBoxHeight/2)+"px;opacity: 1;z-index:10002;";
				_this.params.isMessage.style.cssText = "opacity: 1;z-index:10002;";
			}
		}
		setMessageLayerCss()
	};
	this.hideSelectLayer = function(){
		_this.hideLayer();
		_this.utiliLayer.style.display = "none";
	};
	this.hideMessage = function (){
		_this.hideLayer();
		_this.params.isMessage.style.display = "none";
	};
	this.showLoading = function(){
		_this.showLayer();
		if(_this.params.isLoading){
			_this.params.isLoading.style.display = "block";
		}else{
			_this.params.isLoading = document.createElement("div");
			_this.params.isLoading.className = "preloader";
			$("body")[0].appendChild(_this.params.isLoading);
		}
	}
	this.hideLayer = function (){
		if(_this.layer){
			_this.layer.className = "item-layer hideItemLayer";
		}
	}
	this.hideLoading = function (){
		_this.hideLayer();
		if(_this.params.isLoading){
			_this.params.isLoading.style.display = "none";
		}
	}
}).call(ebt, Zepto);
/**********************underscore-template****************************/
(function() {
	/**
	 * 模板命名空间
	 * @type {*|{}}
	 */
	this.template = this.template || {};

	/**
	 * 渲染模板数据
	 * @param data 渲染数据
	 * @param tem 模板 zepto对象
	 * @param fillto 模板填充zepto对象或者回调函数
	 */
	this.template.render = function(data, tem, fillto) {
		if (window._) {
			var result = _.template(tem.html())(data);
			if ($.isFunction(fillto)) {
				fillto(result);
			} else {
				fillto.append(result);
			}
		} else {
			throw "not find underscore.js";
		}
	};

}).call(ebt);

/*****************form***************/
(function($) {
	var _this = this;
	_this.form = _this.form || {};

	//获取验证码
	//element:点击元素
	//time:倒计时时间
	_this.form.verificationCode = function(element, time, callback, text) {
		var endTime = new Date().getTime() + (time * 1000),
			text = text || "获取动态码";
		$(element).toggleClass("active-code-send");
		_timer(element, time, callback, endTime, text);
	};

	//倒计时
	//element:点击元素
	//t:倒计时时间，单位秒

	function _timer(element, t, callback, endTime, text) {
		if (t <= 0) {
			if ($.isFunction(callback)) {
				callback(true);
			}
			$(element).attr("disabled", false).html(text);
			$(element).toggleClass("active-code-send");
			return false;
		} else {
			t = (endTime - new Date().getTime()) / 1000;
			try {
				t = parseInt(t);
			} catch (e) {
				t = 0;
			}
			$(element).attr("disabled", true).html("<i>" + t + "秒</i>");
			//t--;
			window.setTimeout(function() {
				_timer(element, t, callback, endTime, text);
			}, 1000);
		}
	}
}).call(ebt, Zepto);



/***********openid相关***********/
(function() {
	var _this = this;
	_this.open_id = _this.open_id || {};

	/**
	 * 保存openid
	 * @param v
	 */
	_this.open_id.saveOpenId = function(v) {
		_this.setLocalStorage("zxyd_openid", v);
	};

	/**
	 * 检查openid是否一致
	 * @param v
	 */
	_this.open_id.checkedOpenId = function(v) {
		v = v || _this.getQueryString("openid");
		return (_this.getLocalStorage("zxyd_openid") == v && (_this.getLocalStorage("zxyd_openid") !== ""));
	};

	/**
	 * 页面字体自适应
	 */
	/*(function() {
		function c() {
			var a = document.documentElement,
				b = a.getBoundingClientRect().width;
			// 640<=b?b=640:320>=b&&(b=320);
			b = b >= 640 ? 640 : b <= 320 ? 320 : b;
			a.style.fontSize = Math.floor(b / 26) + "px";
		}
		//c();
		var e = null;
		$(window).on("resize", function() {
			if (!e) {
				e = setTimeout(function() {
					c();
					e = null;
				}, 300);
			}
		});
	})();*/

}).call(ebt);


/**
 * 分享
 */
(function($) {
	var _this = this;

	_this.share = _this.share || {};

	_this.share.shareUrl = "";
	_this.share.wxLink = "";
	var _Arr = ebt.getShareUrl();
	if (_Arr[1] == "ft" || _Arr[1] == "sit") {
		//_this.share.wxLink = "http://112.64.185.148/ECPIC/urlprocess.jsp?wxURL=";
		_this.share.wxLink = "http://wxtest.cpic.com.cn/ECPIC/urlprocess.jsp?wxURL=";
		if(_Arr[1] == "ft"){
			//_this.share.shareUrl = "http://116.228.131.213/cpicmobile_ft/pages/wap/html";
			_this.share.shareUrl = "http://wxtest.cpic.com.cn/cpicmobile_ft/pages/wap/html";
		}else{
			//_this.share.shareUrl = "http://116.228.131.213/cpicmobile/pages/wap/html";
			_this.share.shareUrl = "http://mcdsit.ecpic.com.cn/cpicmobile/pages/wap/html";
			//_this.share.shareUrl = "http://wxtest.cpic.com.cn/cpicmobile/pages/wap/html";
		}
	} else {
		_this.share.wxLink = "http://112.64.185.82/ECPIC/urlprocess.jsp?wxURL=";
		_this.share.shareUrl = "http://m.ecpic.com.cn";
	}

	/**
	 * 初始化分享
	 * @param params
	 */
	_this.share.init = function(params) {
		params = params || {};
		var defaultp = {
			uri: "",
			img_url: "",
			timeline: { //朋友圈
				title: ""
			},
			message: { //好友
				title: "",
				desc: ""
			}
		};

		$.extend(true, defaultp, params);
		if (typeof wx != "undefined") {
			var environmentUrl = _this.getShareUrl();
			var urlPath = environmentUrl[0];
			var img_url = defaultp.img_url;
			var share_url = defaultp.uri;

			wx.ready(function() {
				wx.onMenuShareTimeline({ //分享到朋友圈
					title: defaultp.timeline.title, // 分享标题
					link: share_url, // 分享链接
					imgUrl: img_url, // 分享图标
					success: function() {

					},
					cancel: function() {

					}
				});

				wx.onMenuShareAppMessage({ //发送给好友
					title: defaultp.message.title, // 分享标题
					desc: defaultp.message.desc, // 分享描述
					// desc:'我在太平洋保险e服务免费领取了“蹭网险”小伙伴们速速来领~',
					link: share_url, // 分享链接
					imgUrl: img_url, // 分享图标
					type: '', // 分享类型,music、video或link，不填默认为link
					dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
					success: function() {

					},
					cancel: function() {

					}
				});
			});

			$(function() {
				_this.ajax.post({
					showLoading: true, //不显示load框
					transCode: _this.transCode.E1010,
					request: {
						urlAddress: encodeURIComponent(window.location.href.split("#")[0])
					},
					callback: function(response, status) {
						var d = response.responseBody;
						if (status == _this.dictionary.success) {
							wx.config({
								debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
								appId: _this.authorize_appid, // 必填，公众号的唯一标识
								timestamp: d.timestamp, // 必填，生成签名的时间戳
								nonceStr: d.nonceStr, // 必填，生成签名的随机串
								signature: d.signature, // 必填，签名，见附录1
								jsApiList: [
										'onMenuShareTimeline',
										'onMenuShareAppMessage'
									] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
							});

						}
					}
				});

			});
		}
	};
}).call(ebt, Zepto);
/**
 * 关闭当前窗口
 */
(function($) {
    var _this = this;

    _this.wxClose = _this.wxClose || {};

    /**
     * 初始化分享
     * @param params
     */
    _this.wxClose.init = function() {
        if (typeof wx != "undefined") {
           
            wx.ready(function() {
                wx.closeWindow();
            });

            $(function() {
                _this.ajax.post({
                    showLoading: false, //不显示load框
                    transCode: _this.transCode.E1010,
                    request: {
                        urlAddress: encodeURIComponent(window.location.href.split("#")[0])
                    },
                    callback: function(response, status) {
                        var d = response.responseBody;
                        if (status == _this.dictionary.success) {
                            wx.config({
                                debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                                appId: _this.authorize_appid, // 必填，公众号的唯一标识
                                timestamp: d.timestamp, // 必填，生成签名的时间戳
                                nonceStr: d.nonceStr, // 必填，生成签名的随机串
                                signature: d.signature, // 必填，签名，见附录1
                                jsApiList: [
                                        'closeWindow'
                                    ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                            });

                        }
                    }
                });

            });
        }
    };
}).call(ebt, Zepto);

(function(){
	this.gchannel = function(){
		var gchannel = ebt.getQueryString("gchannel");
		if(gchannel){
			if(gchannel.match(/MicroMessenger/i)){
				gchannel = "W"
			}else{
				gchannel = gchannel;
			}
		}else{
			if(window.localStorage.getItem("gchannel")){
				gchannel = window.localStorage.getItem("gchannel");
			}else{
				if(navigator.appVersion.match(/MicroMessenger/i)){
					//微信
					gchannel="W";
				}else{
					//其他 默认为触屏版
					gchannel="T";
				}
			}
		}
		return gchannel;
	}
}).call(ebt, Zepto);
/**********************sms****************************/
(function ($) {

	var _this = this;
	_this.sms = _this.sms || {};

	/** sms.getVerificationCode 获取验证码
	 * @params{
	               transCode:string,//交易编号(P0001)
	               request:{
	                    openID:string,//openID
	                    mobile:string //电话号码
	               },
	               callback:function(response,status)//回调函数 response-响应报文,status-http请求状态
	             }
	 * @请求报文示例
	 {
         "transCode":"P0001",
         "requset": {
             "openID":"xojouadadsda123",
             "mobile": "15812029303"
         },
         callback:function(response,status){}
     }
	 * @响应报文示例
	 {
         transCode:"",//交易编号
         status:"",//请求响应状态
         costTime:100,//处理费时
         errorCode:'',//错误代码
         errorMsg:"",//错误描述
         "responseBody": {
             "result":"1" //1、获取成功，0、获取失败
         }
     }

	 **/
	this.sms.getVerificationCode = function (params) {
		//默认请求报文参数
		var dp = {
			transCode: _this.transCode.P0001,
			request: {
				phoneNum: '' //电话号码
			},
			callback: function (response, status) {

			}
		};
		_this.ajax.post(dp, params);
	};


}).call(ebt, Zepto);

//电子签名
(function(){
	var _this = this, apiInstance, isSignaReady = false;
	this.ca = this.ca || {};
	//默认数据
	this.params = {
		title : "",
		userInfo : {}
	};
	/**
	 * 配置模板数据
	 */
	this.ca.setTableData = function(channel, form){
		var param = _this.params.userInfo;
		var formData = param.userList[0].formData || {};//{"bjcaxssrequest":{"submitinfo":param.userList.formData}};
		if(form){
			formData = form.userList[0].formData || {};
		}
		formData = JSON.stringify(formData);
		var signer = {"bjcaxssrequest":{"submitinfo":[]}};
		for(var i = 0; i < param.userList.length; i++){
			var signerJson= {};
			signerJson.username = param.userList[i].username;
			signerJson.identitycardnbr = param.userList[i].identitycardnbr;
			signer.bjcaxssrequest.submitinfo.push(signerJson);
		}
		signer = JSON.stringify(signer);
		var tid = _this.params.userInfo.tid || "150";
		var charset = "utf-8";
		var businessId = "719314ea7b88304004c8ff498";
		var template_serial = "1#4000";
		var channel = param.channel || "1000086";

		var res = apiInstance.setData(13, formData);
		res = apiInstance.setData(14, signer);
		res = apiInstance.setData(15, "hash");
		res = apiInstance.setData(16, channel);
		apiInstance.setTID(tid);
		return res;
	};

	this.addSignatureObj = function(objId){
		var context_id = objId;
		var signatureConfig = new SignatureConfig();
		signatureConfig.title = _this.params.title || '请投保人签名';
		var res = apiInstance.addSignatureObj(context_id,signatureConfig);
		if(res){return res;}else{return res;}
	};
	/**
	 * 初始化接口
	 * @param channel 渠道号
	 */
	this.initAnySign = function(channel){
		var res;
		/**
		 * 测试回调，将回调数据显示
		 * @param context_id
		 * @param context_type
		 * @param val
		 */

		var callback = function(context_id,context_type,val)
		{
			if(context_type == CALLBACK_TYPE_START_RECORDING || context_type == CALLBACK_TYPE_STOP_RECORDING)
			{
				return;
			}
			if(context_type == CALLBACK_TYPE_SIGNATURE)
			{
				document.getElementById("xss_20").src = "data:image/gif;base64," + val;
			}
			else if(context_type == CALLBACK_TYPE_ON_PICTURE_TAKEN)
			{
				document.getElementById("preview").src = "data:image/gif;base64," + val;
			}else if(context_type == CALLBACK_TYPE_ON_MEDIA_DATA)
			{
				var audio = document.createElement("audio");
				if (audio != null && audio.canPlayType && audio.canPlayType("audio/mpeg"))
				{
					audio.src = "data:image/gif;base64," + val;
					audio.play();
				}
			}
		};

		apiInstance = new AnySignApi();
		res = apiInstance.initAnySignApi(callback,channel);
		//注册单字签字对象20
		res = _this.addSignatureObj(20, channel || "");
		apiInstance.addDataObj(13, new DataObj());//配置数据域13
		apiInstance.addDataObj(14, new DataObj());//配置数据域14
		apiInstance.addDataObj(15, new DataObj());//配置数据域15
		res = apiInstance.commitConfig();
	};
	/**
	 * 显示信手书  电子签名
	 * @param context_id
	 */
	this.showPopupDialog = function(context_id)
	{
		if(!apiInstance){
			return false;
		}
		switch (apiInstance.showSignatureDialog(context_id))
		{
			case RESULT_OK:
				break;
			case EC_API_NOT_INITED:
				alert("信手书接口没有初始化");
				break;
			case EC_WRONG_CONTEXT_ID:
				alert("没有配置相应context_id的签字对象");
				break;
		}
	};

	/**
	 * 上传数据是否准备就绪
	 */
	this.isReadyToUpload = function(){
		console.log("上传数据是否准备就绪 :" + apiInstance.isReadyToUpload());
	};

	this.getEncodedSignData = function(){
		try
		{
			return apiInstance.getEncodedSignData();
		}
		catch(err)
		{
			return (err.message || "生成数据失败！");
		}
	};
	/**
	 * 创建签名框
	 * @param name 投保人名字
	 */
	this.initElectSignat = function(title){
		_this.params.title = title;
		var str = '<div id="dialog"  style="font-size: 30pt; display:none;">' +
			'<div id="anysign_title"></div>' +
			'<div id="container"  onmousedown = "return false;"><canvas id="anysignCanvas" width="100%" height="70%"></canvas></div>' +
			'<div id="btnContainerOuter" style="display: block; width: 100%;">' +
			'<div id="btnContainerInner" style="text-align: center; width:100%;">' +
			'<input id="btnOK" type="button" class="button orange" value="确 定" onclick="sign_confirm();"/>' +
			'<input id="btnClear" type="button" class="button orange" value="清 屏" onclick="javascript:clear_canvas();">' +
			'<input id="btnCancel" type="button" class="button orange" value="取 消" onclick="cancelSign();"></div></div></div>';

		$("body").append(str);
	};
	this.initAllAny = function(channel){
		ebt.initElectSignat(_this.params.userInfo.title);
		ebt.initAnySign(channel);
		ebt.ca.setTableData(channel);

	};
	this.ca.init = function(param){
		//116.228.131.213 * 10.192.113.53 * /cpicmobile/pages/wap/html
		var loca = window.location.host;
		var host = "m.ecpic.com.cn", linkUrl = "";
		if(loca.indexOf("localhost") > -1 || loca.indexOf("10.192.") > -1){
			host = "10.192.113.53";
			linkUrl = "/cpicmobile/pages/wap/html";
		}else if(loca.indexOf("116.228.") > -1){
			host = "116.228.131.213";
			linkUrl = "/cpicmobile/pages/wap/html";
		}
		_this.loadJsCssFile({
			filename: [
				"http://"+host+ linkUrl +"/newweb/resources/ca/anysign_all.min.js",
				"http://"+host+ linkUrl +"/newweb/resources/ca/css/canvas_css.css",
				"http://"+host+ linkUrl +"/newweb/resources/ca/css/sp.css",
				"http://"+host+ linkUrl +"/newweb/resources/ca/css/mw480Portrait.css",
				"http://"+host+ linkUrl +"/newweb/resources/ca/CryptoJS v3.1.2/rollups/tripledes.js",
				"http://"+host+ linkUrl +"/newweb/resources/ca/CryptoJS v3.1.2/components/mode-ecb.js"
			],
			callback: function(status) {
				_this.initAllAny(param.channel || "1000086");
			}
		});
		var response = ebt.getEncodedSignData();
		ebt.params.userInfo = param;
	}
}).call(ebt, Zepto);
var UTIL = UTIL || {};
UTIL.getShareUrl = function(){
	if(ebt.getShareUrl()[1] == "sit"){
		return "/cpicmobile";
	}else{
		return "/cpicmobile_ft";
	}
};
//设置当前功能属性值  参数1：功能标题  参数2 功能路径 参数3功能对应图标
UTIL.initFuncPage = function(_title_,_url_,_img_){
	UTIL.g_title = _title_;
	UTIL.g_url = _url_;
	UTIL.g_img = _img_;
};
//安卓端获取收藏页面信息
if($('#notEbaotongCollect').val()==undefined){
	UTIL.offerFavoritesForAndroid = function(){
		window.utils.getFavoritesInfo(UTIL.g_title,UTIL.g_url,UTIL.g_img);
	};
}
//app终端获取用户信息
UTIL.appTerminalUser = function(){
	//var sessionlogined = window.sessionStorage['logined'];
	//var sessionUsername = window.sessionStorage['username'];
	/*切a2*/
	//var sessionlogined, sessionUsername;
	//if(UTIL.isLogined().logined){
	//	sessionlogined = window.localStorage['EBT_logined'];
	//	sessionUsername= window.localStorage['EBT_username'];
	//}else{
	//	sessionlogined = "false";
	//	sessionUsername = "";
	//}
	//return {'logined':sessionlogined,'username':sessionUsername};
	return {'logined':window.sessionStorage.getItem('islogin_login_a2'),'username':window.sessionStorage.getItem('username_login_a2')};
};
//安卓获取登陆信息
UTIL.offerLoginInfoForAndroid = function(){
	//var sessionlogined = window.sessionStorage['logined'];
	//var sessionUsername = window.sessionStorage['username'];
	/*切a2*/
	//var sessionlogined, sessionUsername;
	//if(UTIL.isLogined().logined){
	//	sessionlogined = window.localStorage['EBT_logined'];
	//	sessionUsername= window.localStorage['EBT_username'];
	//}else{
	//	sessionlogined = "false";
	//	sessionUsername = "";
	//}
	//window.utils.isLogin(sessionlogined, sessionUsername);
	window.utils.isLogin(islogin_login_a2, username_login_a2);
};
//安卓手机baiduid
UTIL.storeBaiduIdForAndroid = function(jsonStr){
	var channelId=jsonStr.baiDuchannelId;
	var userId=jsonStr.baiDuUserId;
	var udid=jsonStr.deviceUUDI;
	var memberId=jsonStr.UserId;
	window.sessionStorage['bd_channelId']=channelId;
	window.sessionStorage['bd_userId']=userId;
	window.sessionStorage['bd_udid']=udid;
	window.sessionStorage['bd_memberId']=memberId;
	window.sessionStorage['bd_phoneType']="android";
};
//IOS手机baiduid
UTIL.storeBaiduIdForIOS = function(jsonStr){
	var channelId=jsonStr.split(',')[0];
	var userId=jsonStr.split(',')[1];
	var udid=jsonStr.split(',')[2];
	if(UTIL.isEmpty(channelId)||UTIL.isEmpty(userId))return;
	window.sessionStorage['bd_channelId']=channelId;
	window.sessionStorage['bd_userId']=userId;
	window.sessionStorage['bd_udid']="ios";
	window.sessionStorage['bd_phoneType']="ios";
};
UTIL.isSessionLogined = function(){
	var sessionSto = window.sessionStorage;
	if(sessionSto){
		if(!sessionSto['islogined']){
			return UTIL.isLogined();
		}
	}
};
// 判断用户是否登录,true表示已经登录，false未登录
UTIL.isLogined = function() {
	var _loginflag_ = {'logined':false};
	var url = "/basement/isLogined.msp";
	$.ajax({
		async		: 	false,
		timeout	:	180000,
		type		:	"post",
		dataType	:   "json",
		url		:   UTIL.getShareUrl() + url,
		success	: function(d) {
			_loginflag_ = d;
		},
		error		:	function(d){
			_loginflag_ = {'logined':false};
		}
	});
	return _loginflag_;
};
//注销
UTIL.loginout = function(url){
	window.location.href = (ebt.getShareUrl())[0]+"/app/v4/user/loginout.html?pagesUrl="+url;
};
//注销
UTIL.loginoutios = function(){
	var url = "/basement/loginout.msp";
	var _loginflag_= '';
	$.ajax({
		async		: 	false,
		timeout	:	180000,
		type		:	"post",
		dataType	:   "json",
		url		:   UTIL.getShareUrl() + url,
		success	: function(d) {
			if(window.localStorage){
				window.sessionStorage.clear();
				window.localStorage['ebaotongusername'] ='';
				window.localStorage['ebaotongps'] ='';
				window.localStorage['EBT_logined'] ='';
				window.localStorage['EBT_username'] ='';
				window.localStorage.clear();
			}
			_loginflag_ = {'loginout':true};
		},
		error		:	function(d){
			_loginflag_ = {'loginout':false};
		}
	});
	return _loginflag_;
};
(function($){
	this.gversion = function(){
		var _version = ebt.getQueryString("version")||"";
		if("" == _version){
			_version = window.localStorage.getItem("version") || "";
		}
		return _version;
	};
}).call(ebt, Zepto);
//新样式改版=====================start=====================================
(function($){
	//输入框获得焦点时，指定下边框变变色======特殊结构布局情况下使用======个别处理
	this.resetInputFocusById = function(id,lineid){
		$("#"+id).focus(function(){
			if($(this).attr("disfocus")!=null)return;
			$(".activebottom_com").removeClass("activebottom_com");
			$("#"+lineid).addClass("activebottom_com");
		});
	};

	//点击之后设置父节点的下边框的颜色为选中颜色=========非input标签处理下边框变色======父节点下边框变色=====个别处理
	//用法：<div class="e-radio" id="sex" onclick="ebt.setFocusBottom(this);"></div>
	this.setFocusBottom = function(e){
		$(".activebottom_com").removeClass("activebottom_com");
		$(e).parent().addClass("activebottom_com");
	};

	//点击之后设置指定节点的下边框的颜色为选中颜色========非input标签处理====设置指定下边框变色=====个别处理
	//用法：<div class="e-radio" id="sex" onclick="ebt.setFocusBottom(parentId);"></div>
	this.setFocusBottomById = function(id){
		$(".activebottom_com").removeClass("activebottom_com");
		$("#"+id).addClass("activebottom_com");
	};

	//信息披露
	this.setProductclaimshow = function(id,channel){
		var url = "";
		var _Arr = ebt.getShareUrl();
		if(_Arr[1]==""){//生产
			url = "http://m.ecpic.com.cn/newweb/pages/productclaimshow/pages/index.html";
		}else if(_Arr[1]=="sit"){//集成
			url = "http://mcdsit.ecpic.com.cn/cpicmobile/pages/wap/html/newweb/pages/productclaimshow/pages/index.html";
		}else{//开发
			url = "http://10.182.23.144/cpicmobile/pages/wap/html/newweb/pages/productclaimshow/pages/index.html";
		}

		//本地
		if(window.location.href.indexOf("http://localhost/")>=0){
			url = "http://localhost/ebaotong/html/pages/wap/html/newweb/pages/productclaimshow/pages/index.html";
		}
		if(url!==""){
			url = url + "?id="+id+"&gchannel="+channel+"&version="+(ebt.gversion()||"");
			$("#readinformation").attr("href",url)
		}
	};
	//校验报错提示
	this.valiDataCallBack = function(message, id,bl){
		$(".form-error").remove();
		$(".activebottom_com").removeClass("activebottom_com");
		$(".active-close").addClass("hide");
		$("#"+id).parent().after('<strong class="form-error">'+message+'</strong>');
		if(bl !="1") {
			$(window).scrollTop(($("#" + id).offset().top - 20));
		}
	};
}).call(ebt, Zepto);

//显示删除小按钮 、默认情况下设置输入框获得焦点时，下边框变变色===全局处理
(function(a, $) {
	a.bindCommonEvent = function(d) {
		d = d || $("input[type=text],[type=tel],[type=email],[type=password]");
		$(d).each(function(f, e) {
			var $e = $(e);
			$e.off("focus").on("focus",function(){
				if($(this).attr("disfocus")==null){
					$(".activebottom_com").removeClass("activebottom_com");
					$(this).parent().addClass("activebottom_com");
				}
				if($e.attr("readonly")==null){
					$(".active-close").addClass("hide");
					var $g = $($e.next(".active-close"));
					if ($(this).val() == "") {
						$g.addClass("hide");
					} else {
						$g.removeClass("hide").off().click(function() {
							$(this).prev("input").val("").focus();
							$(this).addClass("hide");
						});
					}
				}else{
					$(this)[0].blur();
				}
			});
			if($e.attr("readonly")==null){
				$e.on("input", function() {
					if($(this).attr("readonly")!=null)return;
					var $g = $($e.next(".active-close"));
					if ($(this).val() == "") {
						$g.addClass("hide");
					} else {
						$g.removeClass("hide").off().click(function() {
							$(this).prev("input").val("").focus().addClass("hide");
							$(this).addClass("hide");
						});
					}
				}).off("blur").on("blur",function(){
					window.setTimeout(function(){
						var $parent = $e.parent("div");
						if($parent.length==0){
							$parent = $e.parent().parent("div");
						}
						if(!$parent.hasClass("activebottom_com")){
							$e.next(".active-close").addClass("hide");
						}
					},50);
				});
				if($e.next(".active-close").length==0){
					$e.after('<span class="active-close hide"></span>');
				}
			}

			var $parent = $e.parent("div");
			if($parent.length==0){
				$parent = $e.parent().parent("div");
			}
			$parent.off("click").on("click",function(){
				var $inputChildren = $(this).find("input");
				if($inputChildren.length==1||!$(this).hasClass("activebottom_com")){
					var $obj = $($inputChildren[0]);
					if($obj.attr("type")=="hidden")return;

					$obj.focus();
					if($(".utiliLayer").length==0){
						$obj[0].click();
					}
				}else if($(this).hasClass("activebottom_com")){
					if($inputChildren.length>1&&$(this).hasClass("activebottom_com")){
						var $obj;// = $($inputChildren[0]);
						var $thisObj;
						for(var i=0;i<$inputChildren.length;i++){
							$thisObj = $($inputChildren[i]).next();
							if($thisObj.hasClass("active-close hide")==false&&$thisObj.hasClass("active-close")==true){
								$obj = $($inputChildren[i]);
								break;
							}
						}
						if(!$obj) return;
						if($obj.attr("type")=="hidden")return;
						$obj.focus();
					}
				}
			});
		})
	};
	a.bindCommonEvent();
})(ebt, Zepto);

//分享 部署
(function($){
	this.pageShare = function(channel, openid, subOtherSource, otherUrl){
		if ("W"!= channel) {return;}

		var shareList = ebt.shareList;
		if(undefined == shareList) return;

		var wxLink = ebt.share.wxLink,
			shareUrl = ebt.share.shareUrl;
		var url = shareList.url;
		if("" == openid){//获取openid
			var urlWx = url +(url.indexOf("?")==-1?"?":(url.substr(-1,1)=="?"?"":"&"))+ "subOtherSource=" + subOtherSource;
			//var urlWx = url + "?subOtherSource=" + subOtherSource;
			if(undefined != otherUrl && "" != otherUrl && null != otherUrl){
				urlWx = urlWx + "&"+otherUrl;
			}
			window.location.href =  wxLink + shareUrl  + window.encodeURIComponent(urlWx);
			return;
		}

		var img_url = shareList.img_url||"",
			friendMsg = shareList.friendMsg||"";
		if("" == img_url || "" == friendMsg){
			return;
		}

		var shareUrlEncode = url;
		if(undefined != otherUrl && "" != otherUrl && null != otherUrl){
			shareUrlEncode = shareUrlEncode + (shareUrlEncode.indexOf("?")==-1?"?":(shareUrlEncode.substr(-1,1)=="?"?"":"&"))+otherUrl;
		}
		shareUrlEncode = window.encodeURIComponent(shareUrlEncode);
		ebt.share.init({
			uri : wxLink + shareUrl + shareUrlEncode,
			img_url : shareUrl + img_url,
			timeline : {//朋友圈
				title : shareList.friendCircleMsg
			},
			message : {//好友
				title : friendMsg.title,
				desc : friendMsg.desc
			}
		});
	};
	this.pageOmniture = function(index, channel){
		if(index <= 0){return;};
		var omnituoreList = ebt.OmnitureList;
		if(undefined == omnituoreList){return;};

		var arrList = omnituoreList[channel];
		if((undefined == arrList) || (0 == arrList.length)){return;}

		ebt.omniture.t(arrList[index-1]);
	};
}).call(ebt,Zepto);

//老产品ajax取数
(function($){
	var _this = this;
	/**
	 * 定义ajax方法 针对老产品ajax请求
	 */
	this.ajax1 = function() {
		var ajaxCount = 0;

		var _ajaxCount = 0, //发起ajax的次数(只为处理loading效果)
			_ajaxCompleteCount = 0; //完成ajax的次数(只为处理loading效果)

		function _getPostOptions(notShowLoading) {
			return {
				async: true,
				beforeSend: function(XHR) {
					if (window.one && window.one.ui) {
						if (!notShowLoading) {
							_ajaxCount++;
							one.ui.loading().open();
						}
					}else if(ebt.showLoading){
						if (!notShowLoading) {
							_ajaxCount++;
							ebt.showLoading();
						}
					}
				},
				complete: function(XHR, TS) { //部分手机请求完成不会进入该函数
				},
				contentType: "application/x-www-form-urlencoded",
				data: "",
				dataType: "json",
				accepts: "application/json",
				error: function(xhr, errorType, error) {},
				global: true,
				success: function(data) {},
				timeout: 120000, //60秒超时
				cache: false,
				type: "POST",
				url: ""
			};
		}

		return {
			/**
			 * @示例
			 e.ajax.post({},{request:{}});
			 */
			post: function(dp, params) {
				var c = ++ajaxCount;

				//本地文件直接浏览不发起ajax请求
				if (_this.actionUrl.indexOf("file://") === 0) {
					return;
				}

				$.extend(true, dp, params);

				//不显示加载框
				var notShowLoading = typeof dp.showLoading === "boolean" && !dp.showLoading;
				//忽略的错误集合
				var ignoreError = dp.ignoreError || {};

				var datas = {
					requestBodyJson: JSON.stringify(dp.request),
					transCode: dp.transCode
				};

				var options = {
					url: dp.url || _this.actionUrl,
					data: datas,
					success: function(data) {
						_this.debugPrint(c + ".完成ajax请求 进入success函数<br/>data=" + JSON.stringify(data));
						if (window.one && one.ui) {
							if (!notShowLoading) {
								if(_ajaxCount == ++_ajaxCompleteCount) {
									one.ui.loading().close();
								}
							}
						}else if(ebt.showLayer){
							if (!notShowLoading) {
								if(_ajaxCount == ++_ajaxCompleteCount) {
									ebt.hideLoading();
								}
							}
						}
						if ($.isFunction(dp.callback)) {
							dp.callback(data, _this.dictionary.success);
						}
					},
					error: function(xhr, errorType, error) {

						_this.debugPrint(c + ".完成ajax请求 进入error函数");

						_this.debugPrint("errorType:" + errorType + "/xhr:" + JSON.stringify(xhr) + "/error:" + error);
						if (window.one && one.ui) {
							if (!notShowLoading) {
								if(_ajaxCount == ++_ajaxCompleteCount) {
									one.ui.loading().close();
								}
							}
						}else if(ebt.showLayer){
							if (!notShowLoading) {
								if(_ajaxCount == ++_ajaxCompleteCount) {
									ebt.hideLoading();
								}
							}
						}

						var errorMsg = '';
						if (errorType === "abort" && (!ignoreError.abort)) { //无网络
							errorMsg = "网络已断开";
						} else if (errorType === "timeout" && (!ignoreError.timeout)) { //超时
							errorMsg = "系统连接超时";
						} else if (errorType === "error") { //服务器或者客户端错误
							switch (xhr.status) {
								case 403:
									errorMsg = "服务器禁止访问";
									break;
								case 404:
									errorMsg = "未找到服务器";
									break;
								case 500:
									errorMsg = "服务器未响应";
									break;
								case 503:
									errorMsg = "服务器不可用";
									break;
								case 504:
									errorMsg = "网关超时";
									break;
							}
							//status: int
							//403-禁止访问
							//404-未找到
							//500-内部服务器错误。
							//503-服务不可用。这个错误代码为IIS6.0所专用。
							//504-网关超时。
						}
						//统一获取ajax错误，回调函数
						if ($.isFunction(dp.callback)) {
							dp.callback({
								xhr: xhr,
								errorType: errorType,
								error: error,
								errorMsg: errorMsg
							}, _this.dictionary.fail);
						}
					}
				};
				var _dp = new _getPostOptions(notShowLoading);
				$.extend(_dp, options);
				_this.debugPrint(c + ".发起ajax请求 \r\n目标URL:" + _dp.url + "<br/>formData:" + JSON.stringify(_dp.data));

				$.ajax(_dp);
			},
			get: function(options) {
				var dp = new _getPostOptions();
				$.extend(dp, options);
				$.ajax(dp);
			}
		};
	}();
	this.getAjax1Post = function(params) {
		//默认请求报文参数
		var dp = {
			url: "",
			callback: function(response, status) {
			}
		};
		if(params.url){
			params.url = UTIL.getShareUrl() + params.url;
		}
		_this.ajax1.post(dp, params);
	};
}).call(ebt,Zepto);

(function($){
	var _this = this;
	this.GetUrlParams = function() {
		var url=location.search;
		var theRequest = new Object();
		if(url.indexOf("?")!=-1){
			var str = url.substr(1);
			strs = str.split("&");
			for(var i=0;i<strs.length;i++){
				var sTemp = strs[i].split("=");
				theRequest[sTemp[0]]=(sTemp[1]);
			}
		}
		return theRequest;
	};
}).call(ebt,Zepto);
//新样式改版======================end=====================================

//登陆，注册，会员中心模块切入a2
var envronment_login_a2=(window.location.href.indexOf("http://m.ecpic.com.cn/")>=0||window.location.href.indexOf("http://wap.cpic.com.cn/cpicmobile_ft")>=0)?'prod':((window.location.href.indexOf("cpicmobile_ft") >= 0)?'ft':((window.location.href.indexOf("cpicmobile") >= 0)?'sit':''));
var url_login_status_a2=envronment_login_a2=='prod'?'https://member.cpic.com.cn/cas/ls.json':(envronment_login_a2=='sit'?'https://sitmember.ecpic.com.cn/cas/ls.json':'https://sitmember.ecpic.com.cn/cas/ls.json');
var url_login_url_a2=envronment_login_a2=='prod'?'https://member.cpic.com.cn/cas/login?theme=new':(envronment_login_a2=='sit'?'https://sitmember.ecpic.com.cn/cas/login?theme=new':'https://sitmember.ecpic.com.cn/cas/login?theme=new');
var url_register_url_a2=envronment_login_a2=='prod'?'https://member.cpic.com.cn/ucf/registerW/wregister':(envronment_login_a2=='sit'?'https://sitmember.ecpic.com.cn/ucf/registerW/wregister':'https://sitmember.ecpic.com.cn/ucf/registerW/wregister');
var url_login_weixin_url_a2=envronment_login_a2=='prod'?'http://www.ecpic.com.cn/mall/memberwxrk/weixin/rk':(envronment_login_a2=='sit'?'http://www.test.ecpic.com.cn/mall/memberwxrk/weixin/rk':'http://www.test.ecpic.com.cn/mall/memberwxrk/weixin/rk');
url_register_url_a2+='?gchannel='+ebt.gchannel();
url_login_url_a2+='&gchannel='+ebt.gchannel();
if(ebt.gchannel() == "E"){
	url_login_url_a2+="&version="+ebt.gversion();
}
url_login_weixin_url_a2+='?gchannel='+ebt.gchannel();
var islogin_login_a2=false;
var username_login_a2='';
$.ajax({
	url:url_login_status_a2,
	dataType : "jsonp",
	type:'GET',
	timeout: 120000,
	async:false,
	success:function(d){
		if(d.logined){
			islogin_login_a2=true;
			username_login_a2= d.username;
			window.sessionStorage.setItem('islogin_login_a2',islogin_login_a2);
			window.sessionStorage.setItem('username_login_a2',username_login_a2);
		}
	},
	error:function(d){
	}
});