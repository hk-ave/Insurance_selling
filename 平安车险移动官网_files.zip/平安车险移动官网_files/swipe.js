window.Swipe=function(b,a){if(!b){return null}var c=this;this.options=a||{};this.index=this.options.startSlide||0;this.speed=this.options.speed||300;this.callback=this.options.callback||function(){};
this.delay=this.options.auto||0;this.riues=this.options.riues||false;this.riuesName=this.options.riuesName||false;this.container=b;this.element=this.container.children[0];
this.container.style.overflow="hidden";this.element.style.listStyle="none";this.element.style.margin=0;this.setup();this.begin();if(this.element.addEventListener){this.element.addEventListener("touchstart",this,false);
this.element.addEventListener("touchmove",this,false);this.element.addEventListener("touchend",this,false);this.element.addEventListener("webkitTransitionEnd",this,false);
this.element.addEventListener("msTransitionEnd",this,false);this.element.addEventListener("oTransitionEnd",this,false);this.element.addEventListener("transitionend",this,false);
window.addEventListener("resize",this,false)}};Swipe.prototype={setup:function(){this.slides=this.element.children;this.length=this.slides.length;if(this.length<2){return null
}this.width=("getBoundingClientRect" in this.container)?this.container.getBoundingClientRect().width:this.container.offsetWidth;if(!this.width){return null
}this.container.style.visibility="hidden";this.element.style.width=(this.slides.length*this.width)+"px";var a=this.slides.length;while(a--){var b=this.slides[a];
b.style.width=this.width+"px";b.style.display="table-cell";b.style.verticalAlign="top"}this.slide(this.index,0);this.container.style.visibility="visible"
},slide:function(b,g){var e=this.element.style;if(g==undefined){g=this.speed}e.webkitTransitionDuration=e.MozTransitionDuration=e.msTransitionDuration=e.OTransitionDuration=e.transitionDuration=g+"ms";
e.MozTransform=e.webkitTransform="translate3d("+-(b*this.width)+"px,0,0)";e.msTransform=e.OTransform="translateX("+-(b*this.width)+"px)";this.index=b;if(this.riues==true){var f=this.element.className;
var a=$("."+f+" li").length;var d="";for(var c=0;c<a;c++){d+='<span class="you_ba" id="you_ba'+c+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp</span>'}$("."+this.riuesName).html(d);
$("you_ba").css("background","#0b9fc5");$("#you_ba"+b).css("background","#0b9fc5")}},getPos:function(){return this.index},prev:function(a){this.delay=a||0;
clearTimeout(this.interval);if(this.index){this.slide(this.index-1,this.speed)}},next:function(a){this.delay=a||0;clearTimeout(this.interval);if(this.index<this.length-1){this.slide(this.index+1,this.speed)
}else{this.slide(0,this.speed)}},begin:function(){var a=this;this.interval=(this.delay)?setTimeout(function(){a.next(a.delay)},this.delay):0},stop:function(){this.delay=0;
clearTimeout(this.interval)},resume:function(){this.delay=this.options.auto||0;this.begin()},handleEvent:function(a){switch(a.type){case"touchstart":this.onTouchStart(a);
break;case"touchmove":this.onTouchMove(a);break;case"touchend":this.onTouchEnd(a);break;case"webkitTransitionEnd":case"msTransitionEnd":case"oTransitionEnd":case"transitionend":this.transitionEnd(a);
break;case"resize":this.setup();break}},transitionEnd:function(a){if(this.delay){this.begin()}this.callback(a,this.index,this.slides[this.index])},onTouchStart:function(a){this.start={pageX:a.touches[0].pageX,pageY:a.touches[0].pageY,time:Number(new Date())};
this.isScrolling=undefined;this.deltaX=0;this.element.style.MozTransitionDuration=this.element.style.webkitTransitionDuration=0;a.stopPropagation()},onTouchMove:function(a){if(a.touches.length>1||a.scale&&a.scale!==1){return
}this.deltaX=a.touches[0].pageX-this.start.pageX;if(typeof this.isScrolling=="undefined"){this.isScrolling=!!(this.isScrolling||Math.abs(this.deltaX)<Math.abs(a.touches[0].pageY-this.start.pageY))
}if(!this.isScrolling){a.preventDefault();clearTimeout(this.interval);this.deltaX=this.deltaX/((!this.index&&this.deltaX>0||this.index==this.length-1&&this.deltaX<0)?(Math.abs(this.deltaX)/this.width+1):1);
this.element.style.MozTransform=this.element.style.webkitTransform="translate3d("+(this.deltaX-this.index*this.width)+"px,0,0)";a.stopPropagation()}},onTouchEnd:function(c){var b=Number(new Date())-this.start.time<250&&Math.abs(this.deltaX)>20||Math.abs(this.deltaX)>this.width/2,a=!this.index&&this.deltaX>0||this.index==this.length-1&&this.deltaX<0;
if(!this.isScrolling){this.slide(this.index+(b&&!a?(this.deltaX<0?1:-1):0),this.speed)}c.stopPropagation()}};function pages(){var a=document.getElementById("pages").value;
document.location.href=a};