var Zepto=(function(){var aN,aG,av,a0,am=[],aK=am.slice,au=am.filter,aT=window.document,ap={},al={},ad={"column-count":1,columns:1,"font-weight":1,"line-height":1,opacity:1,"z-index":1,zoom:1},aC=/^\s*<(\w+|!)[^>]*>/,an=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,aQ=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/ig,ar=/^(?:body|html)$/i,aL=/([A-Z])/g,aw=["val","css","html","text","data","width","height","offset"],aB=["after","prepend","before","append"],aF=aT.createElement("table"),ak=aT.createElement("tr"),aS={tr:aT.createElement("tbody"),tbody:aF,thead:aF,tfoot:aF,td:ak,th:ak,"*":aT.createElement("div")},aE=/complete|loaded|interactive/,aP=/^[\w-]*$/,aW={},aU=aW.toString,aX={},af,aj,at=aT.createElement("div"),ac={tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},az=Array.isArray||function(a){return a instanceof Array
};aX.matches=function(b,f){if(!f||!b||b.nodeType!==1){return false}var d=b.webkitMatchesSelector||b.mozMatchesSelector||b.oMatchesSelector||b.matchesSelector;
if(d){return d.call(b,f)}var c,a=b.parentNode,e=!a;if(e){(a=at).appendChild(b)}c=~aX.qsa(a,f).indexOf(b);e&&at.removeChild(b);return c};function aa(a){return a==null?String(a):aW[aU.call(a)]||"object"
}function aJ(a){return aa(a)=="function"}function ao(a){return a!=null&&a==a.window}function aD(a){return a!=null&&a.nodeType==a.DOCUMENT_NODE}function aq(a){return aa(a)=="object"
}function ab(a){return aq(a)&&!ao(a)&&Object.getPrototypeOf(a)==Object.prototype}function ay(a){return typeof a.length=="number"}function ae(a){return au.call(a,function(b){return b!=null
})}function ax(a){return a.length>0?av.fn.concat.apply([],a):a}af=function(a){return a.replace(/-+(.)?/g,function(c,b){return b?b.toUpperCase():""})};function aM(a){return a.replace(/::/g,"/").replace(/([A-Z]+)([A-Z][a-z])/g,"$1_$2").replace(/([a-z\d])([A-Z])/g,"$1_$2").replace(/_/g,"-").toLowerCase()
}aj=function(a){return au.call(a,function(b,c){return a.indexOf(b)==c})};function ai(a){return a in al?al[a]:(al[a]=new RegExp("(^|\\s)"+a+"(\\s|$)"))}function aV(b,a){return(typeof a=="number"&&!ad[aM(b)])?a+"px":a
}function ah(a){var c,b;if(!ap[a]){c=aT.createElement(a);aT.body.appendChild(c);b=getComputedStyle(c,"").getPropertyValue("display");c.parentNode.removeChild(c);
b=="none"&&(b="block");ap[a]=b}return ap[a]}function aH(a){return"children" in a?aK.call(a.children):av.map(a.childNodes,function(b){if(b.nodeType==1){return b
}})}aX.fragment=function(b,d,c){var a,e,f;if(an.test(b)){a=av(aT.createElement(RegExp.$1))}if(!a){if(b.replace){b=b.replace(aQ,"<$1></$2>")}if(d===aN){d=aC.test(b)&&RegExp.$1
}if(!(d in aS)){d="*"}f=aS[d];f.innerHTML=""+b;a=av.each(aK.call(f.childNodes),function(){f.removeChild(this)})}if(ab(c)){e=av(a);av.each(c,function(h,g){if(aw.indexOf(h)>-1){e[h](g)
}else{e.attr(h,g)}})}return a};aX.Z=function(a,b){a=a||[];a.__proto__=av.fn;a.selector=b||"";return a};aX.isZ=function(a){return a instanceof aX.Z};aX.init=function(c,b){var a;
if(!c){return aX.Z()}else{if(typeof c=="string"){c=c.trim();if(c[0]=="<"&&aC.test(c)){a=aX.fragment(c,RegExp.$1,b),c=null}else{if(b!==aN){return av(b).find(c)
}else{a=aX.qsa(aT,c)}}}else{if(aJ(c)){return av(aT).ready(c)}else{if(aX.isZ(c)){return c}else{if(az(c)){a=ae(c)}else{if(aq(c)){a=[c],c=null}else{if(aC.test(c)){a=aX.fragment(c.trim(),RegExp.$1,b),c=null
}else{if(b!==aN){return av(b).find(c)}else{a=aX.qsa(aT,c)}}}}}}}}return aX.Z(a,c)};av=function(b,a){return aX.init(b,a)};function aO(a,b,c){for(aG in b){if(c&&(ab(b[aG])||az(b[aG]))){if(ab(b[aG])&&!ab(a[aG])){a[aG]={}
}if(az(b[aG])&&!az(a[aG])){a[aG]=[]}aO(a[aG],b[aG],c)}else{if(b[aG]!==aN){a[aG]=b[aG]}}}}av.extend=function(a){var c,b=aK.call(arguments,1);if(typeof a=="boolean"){c=a;
a=b.shift()}b.forEach(function(d){aO(a,d,c)});return a};aX.qsa=function(e,g){var b,a=g[0]=="#",f=!a&&g[0]==".",d=a||f?g.slice(1):g,c=aP.test(d);return(aD(e)&&c&&a)?((b=e.getElementById(d))?[b]:[]):(e.nodeType!==1&&e.nodeType!==9)?[]:aK.call(c&&!a?f?e.getElementsByClassName(d):e.getElementsByTagName(g):e.querySelectorAll(g))
};function aA(a,b){return b==null?av(a):av(a).filter(b)}av.contains=function(b,a){return b!==a&&b.contains(a)};function aI(b,c,d,a){return aJ(c)?c.call(b,d,a):c
}function aZ(b,c,a){a==null?b.removeAttribute(c):b.setAttribute(c,a)}function ag(b,a){var d=b.className,c=d&&d.baseVal!==aN;if(a===aN){return c?d.baseVal:d
}c?(d.baseVal=a):(b.className=a)}function aR(b){var c;try{return b?b=="true"||(b=="false"?false:b=="null"?null:!/^0/.test(b)&&!isNaN(c=Number(b))?c:/^[\[\{]/.test(b)?av.parseJSON(b):b):b
}catch(a){return b}}av.type=aa;av.isFunction=aJ;av.isWindow=ao;av.isArray=az;av.isPlainObject=ab;av.isEmptyObject=function(a){var b;for(b in a){return false
}return true};av.inArray=function(b,a,c){return am.indexOf.call(a,b,c)};av.camelCase=af;av.trim=function(a){return a==null?"":String.prototype.trim.call(a)
};av.uuid=0;av.support={};av.expr={};av.map=function(b,a){var c,f=[],d,e;if(ay(b)){for(d=0;d<b.length;d++){c=a(b[d],d);if(c!=null){f.push(c)}}}else{for(e in b){c=a(b[e],e);
if(c!=null){f.push(c)}}}return ax(f)};av.each=function(b,a){var c,d;if(ay(b)){for(c=0;c<b.length;c++){if(a.call(b[c],c,b[c])===false){return b}}}else{for(d in b){if(a.call(b[d],d,b[d])===false){return b
}}}return b};av.grep=function(b,a){return au.call(b,a)};if(window.JSON){av.parseJSON=JSON.parse}av.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),function(a,b){aW["[object "+b+"]"]=b.toLowerCase()
});av.fn={forEach:am.forEach,reduce:am.reduce,push:am.push,sort:am.sort,indexOf:am.indexOf,concat:am.concat,map:function(a){return av(av.map(this,function(b,c){return a.call(b,c,b)
}))},slice:function(){return av(aK.apply(this,arguments))},ready:function(a){if(aE.test(aT.readyState)&&aT.body){a(av)}else{aT.addEventListener("DOMContentLoaded",function(){a(av)
},false)}return this},get:function(a){return a===aN?aK.call(this):this[a>=0?a:a+this.length]},toArray:function(){return this.get()},size:function(){return this.length
},remove:function(){return this.each(function(){if(this.parentNode!=null){this.parentNode.removeChild(this)}})},each:function(a){am.every.call(this,function(b,c){return a.call(b,c,b)!==false
});return this},filter:function(a){if(aJ(a)){return this.not(this.not(a))}return av(au.call(this,function(b){return aX.matches(b,a)}))},add:function(b,a){return av(aj(this.concat(av(b,a))))
},is:function(a){return this.length>0&&aX.matches(this[0],a)},not:function(c){var b=[];if(aJ(c)&&c.call!==aN){this.each(function(d){if(!c.call(this,d)){b.push(this)
}})}else{var a=typeof c=="string"?this.filter(c):(ay(c)&&aJ(c.item))?aK.call(c):av(c);this.forEach(function(d){if(a.indexOf(d)<0){b.push(d)}})}return av(b)
},has:function(a){return this.filter(function(){return aq(a)?av.contains(this,a):av(this).find(a).size()})},eq:function(a){return a===-1?this.slice(a):this.slice(a,+a+1)
},first:function(){var a=this[0];return a&&!aq(a)?a:av(a)},last:function(){var a=this[this.length-1];return a&&!aq(a)?a:av(a)},find:function(b){var c,a=this;
if(typeof b=="object"){c=av(b).filter(function(){var d=this;return am.some.call(a,function(e){return av.contains(e,d)})})}else{if(this.length==1){c=av(aX.qsa(this[0],b))
}else{c=this.map(function(){return aX.qsa(this,b)})}}return c},closest:function(d,c){var b=this[0],a=false;if(typeof d=="object"){a=av(d)}while(b&&!(a?a.indexOf(b)>=0:aX.matches(b,d))){b=b!==c&&!aD(b)&&b.parentNode
}return av(b)},parents:function(c){var a=[],b=this;while(b.length>0){b=av.map(b,function(d){if((d=d.parentNode)&&!aD(d)&&a.indexOf(d)<0){a.push(d);return d
}})}return aA(a,c)},parent:function(a){return aA(aj(this.pluck("parentNode")),a)},children:function(a){return aA(this.map(function(){return aH(this)}),a)
},contents:function(){return this.map(function(){return aK.call(this.childNodes)})},siblings:function(a){return aA(this.map(function(c,b){return au.call(aH(b.parentNode),function(d){return d!==b
})}),a)},empty:function(){return this.each(function(){this.innerHTML=""})},pluck:function(a){return av.map(this,function(b){return b[a]})},show:function(){return this.each(function(){this.style.display=="none"&&(this.style.display="");
if(getComputedStyle(this,"").getPropertyValue("display")=="none"){this.style.display=ah(this.nodeName)}})},replaceWith:function(a){return this.before(a).remove()
},wrap:function(d){var c=aJ(d);if(this[0]&&!c){var b=av(d).get(0),a=b.parentNode||this.length>1}return this.each(function(e){av(this).wrapAll(c?d.call(this,e):a?b.cloneNode(true):b)
})},wrapAll:function(b){if(this[0]){av(this[0]).before(b=av(b));var a;while((a=b.children()).length){b=a.first()}av(b).append(this)}return this},wrapInner:function(b){var a=aJ(b);
return this.each(function(e){var f=av(this),d=f.contents(),c=a?b.call(this,e):b;d.length?d.wrapAll(c):f.append(c)})},unwrap:function(){this.parent().each(function(){av(this).replaceWith(av(this).children())
});return this},clone:function(){return this.map(function(){return this.cloneNode(true)})},hide:function(){return this.css("display","none")},toggle:function(a){return this.each(function(){var b=av(this);
(a===aN?b.css("display")=="none":a)?b.show():b.hide()})},prev:function(a){return av(this.pluck("previousElementSibling")).filter(a||"*")},next:function(a){return av(this.pluck("nextElementSibling")).filter(a||"*")
},html:function(a){return arguments.length===0?(this.length>0?this[0].innerHTML:null):this.each(function(c){var b=this.innerHTML;av(this).empty().append(aI(this,a,c,b))
})},text:function(a){return arguments.length===0?(this.length>0?this[0].textContent:null):this.each(function(){this.textContent=(a===aN)?"":""+a})},attr:function(b,a){var c;
return(typeof b=="string"&&a===aN)?(this.length==0||this[0].nodeType!==1?aN:(b=="value"&&this[0].nodeName=="INPUT")?this.val():(!(c=this[0].getAttribute(b))&&b in this[0])?this[0][b]:c):this.each(function(d){if(this.nodeType!==1){return
}if(aq(b)){for(aG in b){aZ(this,aG,b[aG])}}else{aZ(this,b,aI(this,a,d,this.getAttribute(b)))}})},removeAttr:function(a){return this.each(function(){this.nodeType===1&&aZ(this,a)
})},prop:function(b,a){b=ac[b]||b;return(a===aN)?(this[0]&&this[0][b]):this.each(function(c){this[b]=aI(this,a,c,this[b])})},data:function(c,a){var b=this.attr("data-"+c.replace(aL,"-$1").toLowerCase(),a);
return b!==null?aR(b):aN},val:function(a){return arguments.length===0?(this[0]&&(this[0].multiple?av(this[0]).find("option").filter(function(){return this.selected
}).pluck("value"):this[0].value)):this.each(function(b){this.value=aI(this,a,b,this.value)})},offset:function(a){if(a){return this.each(function(f){var c=av(this),d=aI(this,a,f,c.offset()),g=c.offsetParent().offset(),e={top:d.top-g.top,left:d.left-g.left};
if(c.css("position")=="static"){e.position="relative"}c.css(e)})}if(this.length==0){return null}var b=this[0].getBoundingClientRect();return{left:b.left+window.pageXOffset,top:b.top+window.pageYOffset,width:Math.round(b.width),height:Math.round(b.height)}
},css:function(a,b){if(arguments.length<2){var d=this[0],f=getComputedStyle(d,"");if(!d){return}if(typeof a=="string"){return d.style[af(a)]||f.getPropertyValue(a)
}else{if(az(a)){var c={};av.each(az(a)?a:[a],function(h,g){c[g]=(d.style[af(g)]||f.getPropertyValue(g))});return c}}}var e="";if(aa(a)=="string"){if(!b&&b!==0){this.each(function(){this.style.removeProperty(aM(a))
})}else{e=aM(a)+":"+aV(a,b)}}else{for(aG in a){if(!a[aG]&&a[aG]!==0){this.each(function(){this.style.removeProperty(aM(aG))})}else{e+=aM(aG)+":"+aV(aG,a[aG])+";"
}}}return this.each(function(){this.style.cssText+=";"+e})},index:function(a){return a?this.indexOf(av(a)[0]):this.parent().children().indexOf(this[0])
},hasClass:function(a){if(!a){return false}return am.some.call(this,function(b){return this.test(ag(b))},ai(a))},addClass:function(a){if(!a){return this
}return this.each(function(d){a0=[];var b=ag(this),c=aI(this,a,d,b);c.split(/\s+/g).forEach(function(e){if(!av(this).hasClass(e)){a0.push(e)}},this);a0.length&&ag(this,b+(b?" ":"")+a0.join(" "))
})},removeClass:function(a){return this.each(function(b){if(a===aN){return ag(this,"")}a0=ag(this);aI(this,a,b,a0).split(/\s+/g).forEach(function(c){a0=a0.replace(ai(c)," ")
});ag(this,a0.trim())})},toggleClass:function(a,b){if(!a){return this}return this.each(function(e){var c=av(this),d=aI(this,a,e,ag(this));d.split(/\s+/g).forEach(function(f){(b===aN?!c.hasClass(f):b)?c.addClass(f):c.removeClass(f)
})})},scrollTop:function(a){if(!this.length){return}var b="scrollTop" in this[0];if(a===aN){return b?this[0].scrollTop:this[0].pageYOffset}return this.each(b?function(){this.scrollTop=a
}:function(){this.scrollTo(this.scrollX,a)})},scrollLeft:function(a){if(!this.length){return}var b="scrollLeft" in this[0];if(a===aN){return b?this[0].scrollLeft:this[0].pageXOffset
}return this.each(b?function(){this.scrollLeft=a}:function(){this.scrollTo(a,this.scrollY)})},position:function(){if(!this.length){return}var b=this[0],c=this.offsetParent(),a=this.offset(),d=ar.test(c[0].nodeName)?{top:0,left:0}:c.offset();
a.top-=parseFloat(av(b).css("margin-top"))||0;a.left-=parseFloat(av(b).css("margin-left"))||0;d.top+=parseFloat(av(c[0]).css("border-top-width"))||0;d.left+=parseFloat(av(c[0]).css("border-left-width"))||0;
return{top:a.top-d.top,left:a.left-d.left}},offsetParent:function(){return this.map(function(){var a=this.offsetParent||aT.body;while(a&&!ar.test(a.nodeName)&&av(a).css("position")=="static"){a=a.offsetParent
}return a})}};av.fn.detach=av.fn.remove;["width","height"].forEach(function(a){var b=a.replace(/./,function(c){return c[0].toUpperCase()});av.fn[a]=function(d){var c,e=this[0];
if(d===aN){return ao(e)?e["inner"+b]:aD(e)?e.documentElement["scroll"+b]:(c=this.offset())&&c[a]}else{return this.each(function(f){e=av(this);e.css(a,aI(this,d,f,e[a]()))
})}}});function aY(a,c){c(a);for(var b in a.childNodes){aY(a.childNodes[b],c)}}aB.forEach(function(a,b){var c=b%2;av.fn[a]=function(){var g,f=av.map(arguments,function(h){g=aa(h);
return g=="object"||g=="array"||h==null?h:aX.fragment(h)}),e,d=this.length>1;if(f.length<1){return this}return this.each(function(i,h){e=c?h:h.parentNode;
h=b==0?h.nextSibling:b==1?h.firstChild:b==2?h:null;f.forEach(function(j){if(d){j=j.cloneNode(true)}else{if(!e){return av(j).remove()}}aY(e.insertBefore(j,h),function(k){if(k.nodeName!=null&&k.nodeName.toUpperCase()==="SCRIPT"&&(!k.type||k.type==="text/javascript")&&!k.src){window["eval"].call(window,k.innerHTML)
}})})})};av.fn[c?a+"To":"insert"+(b?"Before":"After")]=function(d){av(d)[a](this);return this}});aX.Z.prototype=av.fn;aX.uniq=aj;aX.deserializeValue=aR;
av.zepto=aX;return av})();window.Zepto=Zepto;window.$===undefined&&(window.$=Zepto);(function(U){var S=1,Q,F=Array.prototype.slice,X=U.isFunction,N=function(a){return typeof a=="string"
},G={},J={},R="onfocusin" in window,I={focus:"focusin",blur:"focusout"},B={mouseenter:"mouseover",mouseleave:"mouseout"};J.click=J.mousedown=J.mouseup=J.mousemove="MouseEvents";
function W(a){return a._zid||(a._zid=S++)}function M(a,d,e,c){d=H(d);if(d.ns){var b=C(d.ns)}return(G[W(a)]||[]).filter(function(f){return f&&(!d.e||f.e==d.e)&&(!d.ns||b.test(f.ns))&&(!e||W(f.fn)===W(e))&&(!c||f.sel==c)
})}function H(b){var a=(""+b).split(".");return{e:a[0],ns:a.slice(1).sort().join(" ")}}function C(a){return new RegExp("(?:^| )"+a.replace(" "," .* ?")+"(?: |$)")
}function O(b,a){return b.del&&(!R&&(b.e in I))||!!a}function D(a){return B[a]||(R&&I[a])||a}function K(b,g,a,c,d,f,h){var e=W(b),i=(G[e]||(G[e]=[]));g.split(/\s/).forEach(function(k){if(k=="ready"){return U(document).ready(a)
}var l=H(k);l.fn=a;l.sel=d;if(l.e in B){a=function(n){var m=n.relatedTarget;if(!m||(m!==this&&!U.contains(this,m))){return l.fn.apply(this,arguments)}}
}l.del=f;var j=f||a;l.proxy=function(n){n=A(n);if(n.isImmediatePropagationStopped()){return}n.data=c;var m=j.apply(b,n._args==Q?[n]:[n].concat(n._args));
if(m===false){n.preventDefault(),n.stopPropagation()}return m};l.i=i.length;i.push(l);if("addEventListener" in b){b.addEventListener(D(l.e),l.proxy,O(l,h))
}})}function z(e,f,c,d,a){var b=W(e);(f||"").split(/\s/).forEach(function(g){M(e,g,c,d).forEach(function(h){delete G[b][h.i];if("removeEventListener" in e){e.removeEventListener(D(h.e),h.proxy,O(h,a))
}})})}U.event={add:K,remove:z};U.proxy=function(c,a){if(X(c)){var b=function(){return c.apply(a,arguments)};b._zid=W(c);return b}else{if(N(a)){return U.proxy(c[a],c)
}else{throw new TypeError("expected function")}}};U.fn.bind=function(b,a,c){return this.on(b,a,c)};U.fn.unbind=function(b,a){return this.off(b,a)};U.fn.one=function(a,c,d,b){return this.on(a,c,d,b,1)
};var E=function(){return true},P=function(){return false},T=/^([A-Z]|returnValue$|layer[XY]$)/,L={preventDefault:"isDefaultPrevented",stopImmediatePropagation:"isImmediatePropagationStopped",stopPropagation:"isPropagationStopped"};
function A(b,a){if(a||!b.isDefaultPrevented){a||(a=b);U.each(L,function(d,e){var c=a[d];b[d]=function(){this[e]=E;return c&&c.apply(a,arguments)};b[e]=P
});if(a.defaultPrevented!==Q?a.defaultPrevented:"returnValue" in a?a.returnValue===false:a.getPreventDefault&&a.getPreventDefault()){b.isDefaultPrevented=E
}}return b}function V(c){var a,b={originalEvent:c};for(a in c){if(!T.test(a)&&c[a]!==Q){b[a]=c[a]}}return A(b,c)}U.fn.delegate=function(b,a,c){return this.on(a,b,c)
};U.fn.undelegate=function(b,a,c){return this.off(a,b,c)};U.fn.live=function(b,a){U(document.body).delegate(this.selector,b,a);return this};U.fn.die=function(b,a){U(document.body).undelegate(this.selector,b,a);
return this};U.fn.on=function(e,g,d,b,f){var h,a,c=this;if(e&&!N(e)){U.each(e,function(i,j){c.on(i,g,d,j,f)});return c}if(!N(g)&&!X(b)&&b!==false){b=d,d=g,g=Q
}if(X(d)||d===false){b=d,d=Q}if(b===false){b=P}return c.each(function(j,i){if(f){h=function(k){z(i,k.type,b);return b.apply(this,arguments)}}if(g){a=function(k){var m,l=U(k.target).closest(g,i).get(0);
if(l&&l!==i){m=U.extend(V(k),{currentTarget:l,liveFired:i});return(h||b).apply(l,[m].concat(F.call(arguments,1)))}}}K(i,e,b,d,g,a||h)})};U.fn.off=function(a,c,b){var d=this;
if(a&&!N(a)){U.each(a,function(e,f){d.off(e,c,f)});return d}if(!N(c)&&!X(b)&&b!==false){b=c,c=Q}if(b===false){b=P}return d.each(function(){z(this,a,b,c)
})};U.fn.trigger=function(a,b){a=(N(a)||U.isPlainObject(a))?U.Event(a):A(a);a._args=b;return this.each(function(){if("dispatchEvent" in this){this.dispatchEvent(a)
}else{U(this).triggerHandler(a,b)}})};U.fn.triggerHandler=function(d,a){var c,b;this.each(function(e,f){c=V(N(d)?U.Event(d):d);c._args=a;c.target=f;U.each(M(f,d.type||d),function(h,g){b=g.proxy(c);
if(c.isImmediatePropagationStopped()){return false}})});return b};("focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select keydown keypress keyup error").split(" ").forEach(function(a){U.fn[a]=function(b){return b?this.bind(a,b):this.trigger(a)
}});["focus","blur"].forEach(function(a){U.fn[a]=function(b){if(b){this.bind(a,b)}else{this.each(function(){try{this[a]()}catch(c){}})}return this}});U.Event=function(d,e){if(!N(d)){e=d,d=e.type
}var b=document.createEvent(J[d]||"Events"),c=true;if(e){for(var a in e){(a=="bubbles")?(c=!!e[a]):(b[a]=e[a])}}b.initEvent(d,c,true);return A(b)}})(Zepto);
(function($){var jsonpID=0,document=window.document,key,name,rscript=/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,scriptTypeRE=/^(?:text|application)\/javascript/i,xmlTypeRE=/^(?:text|application)\/xml/i,jsonType="application/json",htmlType="text/html",blankRE=/^\s*$/;
function triggerAndReturn(context,eventName,data){var event=$.Event(eventName);$(context).trigger(event,data);return !event.isDefaultPrevented()}function triggerGlobal(settings,context,eventName,data){if(settings.global){return triggerAndReturn(context||document,eventName,data)
}}$.active=0;function ajaxStart(settings){if(settings.global&&$.active++===0){triggerGlobal(settings,null,"ajaxStart")}}function ajaxStop(settings){if(settings.global&&!(--$.active)){triggerGlobal(settings,null,"ajaxStop")
}}function ajaxBeforeSend(xhr,settings){var context=settings.context;if(settings.beforeSend.call(context,xhr,settings)===false||triggerGlobal(settings,context,"ajaxBeforeSend",[xhr,settings])===false){return false
}triggerGlobal(settings,context,"ajaxSend",[xhr,settings])}function ajaxSuccess(data,xhr,settings,deferred){var context=settings.context,status="success";
settings.success.call(context,data,status,xhr);if(deferred){deferred.resolveWith(context,[data,status,xhr])}triggerGlobal(settings,context,"ajaxSuccess",[xhr,settings,data]);
ajaxComplete(status,xhr,settings)}function ajaxError(error,type,xhr,settings,deferred){var context=settings.context;settings.error.call(context,xhr,type,error);
if(deferred){deferred.rejectWith(context,[xhr,type,error])}triggerGlobal(settings,context,"ajaxError",[xhr,settings,error||type]);ajaxComplete(type,xhr,settings)
}function ajaxComplete(status,xhr,settings){var context=settings.context;settings.complete.call(context,xhr,status);triggerGlobal(settings,context,"ajaxComplete",[xhr,settings]);
ajaxStop(settings)}function empty(){}$.ajaxJSONP=function(options,deferred){if(!("type" in options)){return $.ajax(options)}var _callbackName=options.jsonpCallback,callbackName=($.isFunction(_callbackName)?_callbackName():_callbackName)||("jsonp"+(++jsonpID)),script=document.createElement("script"),originalCallback=window[callbackName],responseData,abort=function(errorType){$(script).triggerHandler("error",errorType||"abort")
},xhr={abort:abort},abortTimeout;if(deferred){deferred.promise(xhr)}$(script).on("load error",function(e,errorType){clearTimeout(abortTimeout);$(script).off().remove();
if(e.type=="error"||!responseData){ajaxError(null,errorType||"error",xhr,options,deferred)}else{ajaxSuccess(responseData[0],xhr,options,deferred)}window[callbackName]=originalCallback;
if(responseData&&$.isFunction(originalCallback)){originalCallback(responseData[0])}originalCallback=responseData=undefined});if(ajaxBeforeSend(xhr,options)===false){abort("abort");
return xhr}window[callbackName]=function(){responseData=arguments};script.src=options.url.replace(/\?(.+)=\?/,"?$1="+callbackName);document.head.appendChild(script);
if(options.timeout>0){abortTimeout=setTimeout(function(){abort("timeout")},options.timeout)}return xhr};$.ajaxSettings={type:"GET",beforeSend:empty,success:empty,error:empty,complete:empty,context:null,global:true,xhr:function(){return new window.XMLHttpRequest()
},accepts:{script:"text/javascript, application/javascript, application/x-javascript",json:jsonType,xml:"application/xml, text/xml",html:htmlType,text:"text/plain"},crossDomain:false,timeout:0,processData:true,cache:true};
function mimeToDataType(mime){if(mime){mime=mime.split(";",2)[0]}return mime&&(mime==htmlType?"html":mime==jsonType?"json":scriptTypeRE.test(mime)?"script":xmlTypeRE.test(mime)&&"xml")||"text"
}function appendQuery(url,query){if(query==""){return url}return(url+"&"+query).replace(/[&?]{1,2}/,"?")}function serializeData(options){if(options.processData&&options.data&&$.type(options.data)!="string"){options.data=$.param(options.data,options.traditional)
}if(options.data&&(!options.type||options.type.toUpperCase()=="GET")){options.url=appendQuery(options.url,options.data),options.data=undefined}}$.ajax=function(options){var settings=$.extend({},options||{}),deferred=$.Deferred&&$.Deferred();
for(key in $.ajaxSettings){if(settings[key]===undefined){settings[key]=$.ajaxSettings[key]}}ajaxStart(settings);if(!settings.crossDomain){settings.crossDomain=/^([\w-]+:)?\/\/([^\/]+)/.test(settings.url)&&RegExp.$2!=window.location.host
}if(!settings.url){settings.url=window.location.toString()}serializeData(settings);if(settings.cache===false){settings.url=appendQuery(settings.url,"_="+Date.now())
}var dataType=settings.dataType,hasPlaceholder=/\?.+=\?/.test(settings.url);if(dataType=="jsonp"||hasPlaceholder){if(!hasPlaceholder){settings.url=appendQuery(settings.url,settings.jsonp?(settings.jsonp+"=?"):settings.jsonp===false?"":"callback=?")
}return $.ajaxJSONP(settings,deferred)}var mime=settings.accepts[dataType],headers={},setHeader=function(name,value){headers[name.toLowerCase()]=[name,value]
},protocol=/^([\w-]+:)\/\//.test(settings.url)?RegExp.$1:window.location.protocol,xhr=settings.xhr(),nativeSetHeader=xhr.setRequestHeader,abortTimeout;
if(deferred){deferred.promise(xhr)}if(!settings.crossDomain){setHeader("X-Requested-With","XMLHttpRequest")}setHeader("Accept",mime||"*/*");if(mime=settings.mimeType||mime){if(mime.indexOf(",")>-1){mime=mime.split(",",2)[0]
}xhr.overrideMimeType&&xhr.overrideMimeType(mime)}if(settings.contentType||(settings.contentType!==false&&settings.data&&settings.type.toUpperCase()!="GET")){setHeader("Content-Type",settings.contentType||"application/x-www-form-urlencoded")
}if(settings.headers){for(name in settings.headers){setHeader(name,settings.headers[name])}}xhr.setRequestHeader=setHeader;xhr.onreadystatechange=function(){if(xhr.readyState==4){xhr.onreadystatechange=empty;
clearTimeout(abortTimeout);var result,error=false;if((xhr.status>=200&&xhr.status<300)||xhr.status==304||(xhr.status==0&&protocol=="file:")){dataType=dataType||mimeToDataType(settings.mimeType||xhr.getResponseHeader("content-type"));
result=xhr.responseText;try{if(dataType=="script"){(1,eval)(result)}else{if(dataType=="xml"){result=xhr.responseXML}else{if(dataType=="json"){result=blankRE.test(result)?null:$.parseJSON(result)
}}}}catch(e){error=e}if(error){ajaxError(error,"parsererror",xhr,settings,deferred)}else{ajaxSuccess(result,xhr,settings,deferred)}}else{ajaxError(xhr.statusText||null,xhr.status?"error":"abort",xhr,settings,deferred)
}}};if(ajaxBeforeSend(xhr,settings)===false){xhr.abort();ajaxError(null,"abort",xhr,settings,deferred);return xhr}if(settings.xhrFields){for(name in settings.xhrFields){xhr[name]=settings.xhrFields[name]
}}var async="async" in settings?settings.async:true;xhr.open(settings.type,settings.url,async,settings.username,settings.password);for(name in headers){nativeSetHeader.apply(xhr,headers[name])
}if(settings.timeout>0){abortTimeout=setTimeout(function(){xhr.onreadystatechange=empty;xhr.abort();ajaxError(null,"timeout",xhr,settings,deferred)},settings.timeout)
}xhr.send(settings.data?settings.data:null);return xhr};function parseArguments(url,data,success,dataType){if($.isFunction(data)){dataType=success,success=data,data=undefined
}if(!$.isFunction(success)){dataType=success,success=undefined}return{url:url,data:data,success:success,dataType:dataType}}$.get=function(){return $.ajax(parseArguments.apply(null,arguments))
};$.post=function(){var options=parseArguments.apply(null,arguments);options.type="POST";return $.ajax(options)};$.getJSON=function(){var options=parseArguments.apply(null,arguments);
options.dataType="json";return $.ajax(options)};$.fn.load=function(url,data,success){if(!this.length){return this}var self=this,parts=url.split(/\s/),selector,options=parseArguments(url,data,success),callback=options.success;
if(parts.length>1){options.url=parts[0],selector=parts[1]}options.success=function(response){self.html(selector?$("<div>").html(response.replace(rscript,"")).find(selector):response);
callback&&callback.apply(self,arguments)};$.ajax(options);return this};var escape=encodeURIComponent;function serialize(params,obj,traditional,scope){var type,array=$.isArray(obj),hash=$.isPlainObject(obj);
$.each(obj,function(key,value){type=$.type(value);if(scope){key=traditional?scope:scope+"["+(hash||type=="object"||type=="array"?key:"")+"]"}if(!scope&&array){params.add(value.name,value.value)
}else{if(type=="array"||(!traditional&&type=="object")){serialize(params,value,traditional,key)}else{params.add(key,value)}}})}$.param=function(obj,traditional){var params=[];
params.add=function(k,v){this.push(escape(k)+"="+escape(v))};serialize(params,obj,traditional);return params.join("&").replace(/%20/g,"+")}})(Zepto);(function(b){b.fn.serializeArray=function(){var a=[],d;
b([].slice.call(this.get(0).elements)).each(function(){d=b(this);var c=d.attr("type");if(this.nodeName.toLowerCase()!="fieldset"&&!this.disabled&&c!="submit"&&c!="reset"&&c!="button"&&((c!="radio"&&c!="checkbox")||this.checked)){a.push({name:d.attr("name"),value:d.val()})
}});return a};b.fn.serialize=function(){var a=[];this.serializeArray().forEach(function(d){a.push(encodeURIComponent(d.name)+"="+encodeURIComponent(d.value))
});return a.join("&")};b.fn.submit=function(d){if(d){this.bind("submit",d)}else{if(this.length){var a=b.Event("submit");this.eq(0).trigger(a);if(!a.isDefaultPrevented()){this.get(0).submit()
}}}return this}})(Zepto);(function(d){if(!("__proto__" in {})){d.extend(d.zepto,{Z:function(a,b){a=a||[];d.extend(a,d.fn);a.selector=b||"";a.__Z=true;return a
},isZ:function(a){return d.type(a)==="array"&&"__Z" in a}})}try{getComputedStyle(undefined)}catch(f){var e=getComputedStyle;window.getComputedStyle=function(b){try{return e(b)
}catch(a){return null}}}})(Zepto);(function(t){var v={},z,q,u,B,x=750,p;function s(c,d,a,b){return Math.abs(c-d)>=Math.abs(a-b)?(c-d>0?"Left":"Right"):(a-b>0?"Up":"Down")
}function o(){B=null;if(v.last){v.el.trigger("longTap");v={}}}function y(){if(B){clearTimeout(B)}B=null}function w(){if(z){clearTimeout(z)}if(q){clearTimeout(q)
}if(u){clearTimeout(u)}if(B){clearTimeout(B)}z=q=u=B=null;v={}}function r(a){return(a.pointerType=="touch"||a.pointerType==a.MSPOINTER_TYPE_TOUCH)&&a.isPrimary
}function A(a,b){return(a.type=="pointer"+b||a.type.toLowerCase()=="mspointer"+b)}t(document).ready(function(){var d,a,e=0,f=0,b,c;if("MSGesture" in window){p=new MSGesture();
p.target=document.body}t(document).bind("MSGestureEnd",function(g){var h=g.velocityX>1?"Right":g.velocityX<-1?"Left":g.velocityY>1?"Down":g.velocityY<-1?"Up":null;
if(h){v.el.trigger("swipe");v.el.trigger("swipe"+h)}}).on("touchstart MSPointerDown pointerdown",function(g){if((c=A(g,"down"))&&!r(g)){return}b=c?g:g.touches[0];
if(g.touches&&g.touches.length===1&&v.x2){v.x2=undefined;v.y2=undefined}d=Date.now();a=d-(v.last||d);v.el=t("tagName" in b.target?b.target:b.target.parentNode);
z&&clearTimeout(z);v.x1=b.pageX;v.y1=b.pageY;if(a>0&&a<=250){v.isDoubleTap=true}v.last=d;B=setTimeout(o,x);if(p&&c){p.addPointer(g.pointerId)}}).on("touchmove MSPointerMove pointermove",function(g){if((c=A(g,"move"))&&!r(g)){return
}b=c?g:g.touches[0];y();v.x2=b.pageX;v.y2=b.pageY;e+=Math.abs(v.x1-v.x2);f+=Math.abs(v.y1-v.y2)}).on("touchend MSPointerUp pointerup",function(g){if((c=A(g,"up"))&&!r(g)){return
}y();if((v.x2&&Math.abs(v.x1-v.x2)>30)||(v.y2&&Math.abs(v.y1-v.y2)>30)){u=setTimeout(function(){v.el.trigger("swipe");v.el.trigger("swipe"+(s(v.x1,v.x2,v.y1,v.y2)));
v={}},0)}else{if("last" in v){if(e<30&&f<30){q=setTimeout(function(){var h=t.Event("tap");h.cancelTouch=w;v.el.trigger(h);if(v.isDoubleTap){if(v.el){v.el.trigger("doubleTap")
}v={}}else{z=setTimeout(function(){z=null;if(v.el){v.el.trigger("singleTap")}v={}},250)}},0)}else{v={}}}}e=f=0}).on("touchcancel MSPointerCancel pointercancel",w);
t(window).on("scroll",w)});["swipe","swipeLeft","swipeRight","swipeUp","swipeDown","doubleTap","tap","singleTap","longTap"].forEach(function(a){t.fn[a]=function(b){return this.on(a,b)
}})})(Zepto);