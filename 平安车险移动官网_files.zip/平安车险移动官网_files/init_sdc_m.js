;
var gDomain = "sdc.pingan.com"; // SDC Production Mode Domain
var gDcsId = "dcspymm36v5rgwyi354yjpm91_6q9m ";
var gFpc = "WT-FPC";
var gConvert = true;
var gWTIDJS = window.document.createElement("script");
window.document.getElementsByTagName("head")[0].appendChild(gWTIDJS);
if ((typeof (gConvert) != "undefined") && gConvert && (document.cookie.indexOf(gFpc + "=") == -1) && (document.cookie.indexOf("WTLOPTOUT=") == -1)) {
	gWTIDJS.src = "http" + (window.location.protocol.indexOf('https:') == 0 ? 's' : '') + "://" + gDomain + "/" + gDcsId + "/wtid.js";
}

// 先申明一个空函数
function pa_sdcajax() {
}

setTimeout('setsdcjs()', 0);
function setsdcjs() {
	var js_path = 'http://pcss1.4008000000.com/app_css/4008000000/v10/m/upingan/js/webtrends/sdc_m.js';
	var SDC_js = document.createElement("script");
	SDC_js.src = js_path;

	var headElem = document.getElementsByTagName("head")[0];
	headElem.appendChild(SDC_js);
}
