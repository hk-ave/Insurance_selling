(function(){window.App=window.App||{};var j=location.host;App.host=j;App.RequestHost="/upingan/";App.ServerHost="/";if(location.hostname=="localhost"||location.host=="127.0.0.1"){App.ServerHost="http://dmzstg1.pa18.com/"
}App.MediaSource={MOBILE_DEFAULT:"SC03-Direct-00001",ACTIVITY_YJXB_AD:"sc03-yjxb-0000001",ACTIVITY_YJXB_AD2:"sc03-yjxb-0000002",ACTIVITY_YJXB_ZBZYH:"sc03-direct-zbzyh-0000001",ACTIVITY_ALL:"upa-marketing-all",WEIXIN:"sc03-channel-weixin-00000001",AHHS:"ahhs-mobile-wap"};
var f=h("mediasource"),e=h("mt"),g=sessionStorage.getItem("mediasource");if(e=="weixin"){g=App.MediaSource.WEIXIN}if(f){g=f}if(!g){g=App.MediaSource.MOBILE_DEFAULT
}App.setMediasource=function(l){window.sessionStorage.setItem("mediasource",l);App.resource=l;c("MEDIA_SOURCE_NAME",l,{path:"/",domain:".pingan.com"})};
App.getMediasource=function(){return sessionStorage.getItem("mediasource")};App.setMediasource(g);var k=j.indexOf("dmzstg")||j.indexOf("localhost")?true:false;
App.upinganHost=k?"u.pingan.com":"/";App.autoHost=k?"www.pingan.com":"/";function i(n){var m=document.createElement("div"),l=window.innerHeight,o=window.innerWidth;
m.setAttribute("id","beeMasker");m.style.height=l+"px";m.style.width=o+"px";m.style.position="absolute";m.style.top="0";m.style.left="0";m.style.display="none";
m.style.background="url(images/common/loading.gif) 50% 50% no-repeat";document.getElementsByTagName("body")[0].appendChild(m);this.beeMasker=m;this._init()
}i.prototype={_init:function(){i.instance=this},show:function(){this.beeMasker.style.display="block"},hide:function(){this.beeMasker.style.display="none"
}};App.onload=App.loadingBegin=function(){if(i.instance==undefined){new i}i.instance.show()};App.loaded=App.loadingFinish=function(){i.instance.hide()};
App.RequestHost="/upingan/";App.ServerHost="/";if(location.hostname=="localhost"||location.host=="127.0.0.1"){App.ServerHost="http://dmzstg1.pa18.com/"
}App.getWebServiceUrl=function(l){return App.ServerHost+webServiceUrls[name]};App.rumUserIsLogin=function(){if(c("rumUserLogin")){return true}return false
};function h(l){var m=new RegExp("(^|&)"+l+"=([^&]*)(&|$)","i");var n=window.location.search.substr(1).match(m);if(n){return decodeURI(n[2])}return null
}window.getParams=h;function c(q,p,u){if(arguments.length>1&&(!/Object/.test(Object.prototype.toString.call(p))||p===null||p===undefined)){u=u||{};if(p===null||p===undefined){u.expires=-1
}if(typeof u.expires==="number"){var r=u.expires,s=u.expires=new Date();s.setDate(s.getDate()+r)}p=String(p);return(document.cookie=[encodeURIComponent(q),"=",u.raw?p:encodeURIComponent(p),u.expires?"; expires="+u.expires.toUTCString():"",u.path?"; path="+u.path:"",u.domain?"; domain="+u.domain:"",u.secure?"; secure":""].join(""))
}u=p||{};var l=u.raw?function(t){return t}:decodeURIComponent;var m=document.cookie.split("; ");for(var o=0,n;n=m[o]&&m[o].split("=");o++){if(l(n[0])===q){return l(n[1]||"")
}}return null}window.Cookie=c;function a(n,q){var p="";if(typeof q=="string"){if(h(q)){p=q+"="+h(q)}}else{if(typeof q=="object"){var o=0,l=q.length;for(;
o<l;o++){p+=q[o]+"="+h(q[o])+"&"}p=p.slice(0,-1)}else{if(typeof q=="undefined"){var r=location.href.indexOf("?");p=location.href.slice(r+1)}}}var m=n.indexOf("?")=="-1"?"?":"&";
n=n+m+p;return n}window.urlJoint=a;App.rumUserIsLogin=function(){if(c("rumUserLogin")){return true}return false};function d(){var o=location.href.indexOf("?"),r=location.href.slice(o+1);
var n=r.split("&"),p=0,m=n.length,q={};for(;p<m;p++){var l=n[p].split("=");q[l[0]]=l[1]}return q}var b=h("event")||c("eventType")||null;if(b!=null){c("eventType","true");
$("#innerHead").hide();$("#innerFoot").hide()}window.queryToData=d})();